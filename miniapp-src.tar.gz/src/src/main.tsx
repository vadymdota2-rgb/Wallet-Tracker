/** Точка входа. Монтирует приложение и сообщает Telegram, что оно готово. */

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Toaster } from "sonner";
import { App } from "./App";
import { useApp } from "./store";
import "./styles/index.css";

const el = document.getElementById("root");
if (el) {
  // Состояние сохраняется с `skipHydration`, поэтому поднимаем его вручную —
  // до первой отрисовки, иначе экран моргнёт значениями по умолчанию.
  void useApp.persist.rehydrate();

  try {
    window.Telegram?.WebApp?.ready?.();
    window.Telegram?.WebApp?.expand?.();
  } catch {
    /* вне Telegram работаем как обычная страница */
  }

  createRoot(el).render(
    <StrictMode>
      <App />
      <Toaster position="top-center" richColors />
    </StrictMode>,
  );
}
