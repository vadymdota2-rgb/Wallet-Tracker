/**
 * Оболочка: шапка с кнопкой назад и обновлением, вкладки, стек экранов.
 */

import { useEffect, useState } from "react";
import { useApp } from "./store";
import { t } from "./i18n/t";
import { TITLE } from "./screens/registry";
import { ScreenStack } from "./screens/ScreenStack";
import { HomeScreen } from "./screens/HomeScreen";
import { MarketScreen } from "./screens/MarketScreen";
import { PeopleScreen } from "./screens/PeopleScreen";
import { SonarScreen } from "./screens/SonarScreen";
import { Background } from "./components/Background";
import { Drawer } from "./components/Drawer";
import { BackIcon, BurgerIcon, SyncIcon } from "./components/icons";
import { startPolling } from "./lib/live";

export function App() {
  const lang = useApp((s) => s.lang);
  const tab = useApp((s) => s.tab);
  const stack = useApp((s) => s.stack);
  const menuOpen = useApp((s) => s.menuOpen);
  const setMenu = useApp((s) => s.setMenu);
  const back = useApp((s) => s.back);
  const syncNow = useApp((s) => s.syncNow);
  const [spinning, setSpinning] = useState(false);

  const top = stack[stack.length - 1];
  const title = t(lang, TITLE[(top?.name ?? tab) as keyof typeof TITLE]);

  // Первая загрузка и последующий опрос: одна цепочка, останавливается
  // при размонтировании.
  useEffect(() => startPolling(), []);

  // Escape закрывает меню, потом возвращает на шаг назад.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (menuOpen) setMenu(false);
      else if (stack.length) back();
    };
    addEventListener("keydown", onKey);
    return () => removeEventListener("keydown", onKey);
  }, [menuOpen, stack.length, setMenu, back]);

  // Новый экран открывается сверху, а не там, где был скролл прошлого.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [tab, stack.length, top?.name, top?.arg]);

  // Системная кнопка «назад» в Telegram: показываем её только внутри стека.
  useEffect(() => {
    const wa = window.Telegram?.WebApp;
    try {
      wa?.setHeaderColor?.("#01030A");
      wa?.setBackgroundColor?.("#01030A");
    } catch {
      /* старые версии Telegram этого не умеют */
    }
    const btn = wa?.BackButton;
    if (!btn) return;
    if (stack.length) btn.show?.();
    else btn.hide?.();
    btn.onClick?.(back);
    return () => btn.offClick?.(back);
  }, [stack.length, back]);

  return (
    <div className="app">
      <Background />
      <Drawer />
      <div className="stage">
        <header className="top">
          {stack.length ? (
            <button type="button" className="hbtn burger" aria-label={t(lang, "backToChat")} onClick={back}>
              <BackIcon />
            </button>
          ) : (
            <button
              type="button"
              className="hbtn burger menu"
              aria-label={t(lang, "menuAria")}
              aria-expanded={menuOpen}
              onClick={() => setMenu(true)}
            >
              <BurgerIcon />
            </button>
          )}
          <span className="brand">
            <h1 className="htitle">{title}</h1>
          </span>
          <button
            type="button"
            className={`hbtn${spinning ? " spin" : ""}`}
            aria-label={t(lang, "sync")}
            onClick={() => {
              setSpinning(true);
              syncNow();
              // Вращение держим чуть дольше запроса, иначе на быстрой сети
              // кнопка дёргается и кажется, что ничего не произошло.
              setTimeout(() => setSpinning(false), 620);
            }}
          >
            <SyncIcon />
          </button>
        </header>

        <main className="view">
          {top ? (
            <ScreenStack />
          ) : (
            <>
              {tab === "home" && <HomeScreen />}
              {tab === "market" && <MarketScreen />}
              {tab === "people" && <PeopleScreen />}
              {tab === "sonar" && <SonarScreen />}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
