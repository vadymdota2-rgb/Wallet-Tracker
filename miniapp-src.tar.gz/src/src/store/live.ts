/**
 * Живые данные с сервера. Отделены от `useApp` намеренно: то состояние
 * сохраняется в localStorage, а это — нет. Обновляется целиком ответом
 * `/api/bootstrap`, поэтому частичных правок здесь не бывает.
 */

import { create } from "zustand";
import type {
  Bootstrap, Coin, FeedItem, FlowWindow, FundingRow, RankTable,
  RotationLink, SonarState, Wallet, WalletReport,
} from "../lib/types";

interface LiveState {
  /** Данные хотя бы раз пришли. */
  live: boolean;
  coins: Record<string, Coin>;
  feed: FeedItem[];
  /** Поток по окнам: ключ — часы (1, 6, 24, 168, 720). */
  flow: Record<string, FlowWindow>;
  /** Ротация по окнам. */
  rot: Record<string, RotationLink[]>;
  /** Общая лента сделок, не только по своим кошелькам. */
  marketFeed: FeedItem[];
  /** Крупнейшие сделки по разделам. */
  trades: Record<string, FeedItem[]>;
  funding: FundingRow[];
  /**
   * Рейтинг: rank[площадка][сортировка]. Окно сервер сейчас не разделяет —
   * данные тридцатидневные. Прежний бандл на других окнах умножал прибыль
   * на 1.85, 2.7 и 3.9, а доходность на 0.72, 0.58 и 0.44, то есть
   * показывал выдуманные числа как настоящие.
   */
  rank: RankTable;
  /** Окна, по которым сервер реально отдаёт рейтинг. */
  rankWindows: number[];
  sonar: SonarState;
  alertsToday: number;
  /** Алертов за 30 дней — для подписи под порогом. */
  alerts30d: number;
  updatedAt: number;
  /** Разовые отчёты по чужим адресам, ключ — адрес в нижнем регистре. */
  reports: Record<string, WalletReport>;
  apply(data: Bootstrap): Wallet[];
}

export const useLive = create<LiveState>()((set) => ({
  live: false,
  coins: {},
  feed: [],
  flow: {},
  rot: {},
  marketFeed: [],
  trades: {},
  funding: [],
  rank: {},
  rankWindows: [30],
  sonar: { trained: false, ready: {}, need: 200, list: [] },
  alertsToday: 0,
  alerts30d: 0,
  updatedAt: 0,
  reports: {},

  /**
   * Кладёт ответ сервера и возвращает кошельки — их применяет `useApp`,
   * потому что они же лежат в сохраняемом состоянии.
   */
  apply: (data) => {
    set({
      live: true,
      coins: data.coins ?? {},
      feed: data.feed ?? [],
      flow: (data.flow ?? {}) as Record<string, FlowWindow>,
      rot: (data.rot ?? {}) as Record<string, RotationLink[]>,
      marketFeed: data.marketFeed ?? [],
      trades: (data.trades ?? {}) as Record<string, FeedItem[]>,
      funding: (data.funding ?? []) as FundingRow[],
      rank: (data.rank ?? {}) as RankTable,
      rankWindows: Array.isArray(data.rankWindows) ? data.rankWindows : [30],
      sonar: (data.sonar ?? { trained: false, ready: {}, need: 200, list: [] }) as SonarState,
      alertsToday: data.alertsToday ?? data.me?.alertsToday ?? 0,
      alerts30d: data.alerts30d ?? data.me?.alerts30d ?? 0,
      updatedAt: Date.now(),
    });
    return Array.isArray(data.wallets) ? data.wallets : [];
  },
}));
