/**
 * То, чем приложение пользуется из Telegram WebApp. Полного описания
 * намеренно нет: чем меньше объявлено, тем раньше видно обращение к
 * методу, которого может не быть в старой версии клиента.
 */
export {};

declare global {
  interface TelegramBackButton {
    show?: () => void;
    hide?: () => void;
    onClick?: (cb: () => void) => void;
    offClick?: (cb: () => void) => void;
  }

  interface TelegramWebApp {
    initData?: string;
    initDataUnsafe?: { user?: { id?: number; language_code?: string } };
    HapticFeedback?: { selectionChanged?: () => void };
    BackButton?: TelegramBackButton;
    ready?: () => void;
    expand?: () => void;
    /** Появились не во всех версиях клиента — отсюда и вызовы через `?.`. */
    setHeaderColor?: (color: string) => void;
    setBackgroundColor?: (color: string) => void;
    openLink?: (url: string) => void;
  }

  interface Window {
    Telegram?: { WebApp?: TelegramWebApp };
  }
}
