/**
 * Свечи с бирж. Запросы идут через прокси nginx: Binance, её зеркало
 * data-api, Bybit и KuCoin — по очереди, пока какая-нибудь не ответит.
 *
 * Если не ответил никто, возвращается пустой массив. Прежняя версия в
 * этом случае РИСОВАЛА выдуманную историю: тридцать две точки линейной
 * интерполяции между ценой входа и текущей. Пользователь видел «график
 * цены», которого не было.
 */

import type { Candle } from "../components/Candles";

export type Timeframe = "15m" | "1h" | "4h" | "1d" | "1w";

/** Тикеры, торгуемые пачками по тысяче. */
const BULK: Record<string, string> = {
  PEPE: "1000PEPE",
  FLOKI: "1000FLOKI",
  SHIB: "1000SHIB",
  BONK: "1000BONK",
};

const BYBIT_TF: Record<Timeframe, string> = {
  "15m": "15", "1h": "60", "4h": "240", "1d": "D", "1w": "W",
};
const KUCOIN_TF: Record<Timeframe, string> = {
  "15m": "15min", "1h": "1hour", "4h": "4hour", "1d": "1day", "1w": "1week",
};

/** Тикер без разделителей; `kPEPE` сводится к `PEPE`. */
export function baseTicker(sym: string): string {
  const up = String(sym || "").toUpperCase().replace(/[^A-Z0-9]/g, "") || "ETH";
  return up.startsWith("K") && ["PEPE", "FLOKI", "SHIB", "BONK"].includes(up.slice(1))
    ? up.slice(1)
    : up;
}

/** Разбирает ответ любой из четырёх бирж — форматы у них разные. */
function parse(json: unknown): Candle[] | null {
  // Binance: массив массивов, цены со второго элемента.
  if (Array.isArray(json) && Array.isArray(json[0]) && json[0].length > 4) {
    return json.map((k: unknown[]) => ({
      o: Number(k[1]), h: Number(k[2]), l: Number(k[3]), c: Number(k[4]),
    }));
  }
  const obj = json as { result?: { list?: unknown[][] }; data?: unknown[][] };
  // Bybit: свежие идут первыми, разворачиваем.
  if (Array.isArray(obj?.result?.list)) {
    return obj.result.list.slice().reverse().map((k) => ({
      o: Number(k[1]), h: Number(k[2]), l: Number(k[3]), c: Number(k[4]),
    }));
  }
  // KuCoin: другой порядок полей — закрытие идёт до максимума.
  if (Array.isArray(obj?.data) && obj.data[0]) {
    return obj.data.slice().reverse().map((k) => ({
      o: Number(k[1]), h: Number(k[3]), l: Number(k[4]), c: Number(k[2]),
    }));
  }
  return null;
}

const usable = (rows: Candle[] | null): rows is Candle[] =>
  !!rows && rows.length > 0 && rows.every((c) => Number.isFinite(c.c) && c.c > 0);

/** Пробует источники по очереди. Пустой массив означает «данных нет». */
export async function fetchCandles(
  sym: string,
  tf: Timeframe,
  signal?: AbortSignal,
): Promise<Candle[]> {
  const base = baseTicker(sym);
  const pair = (BULK[base] ?? base) + "USDT";
  const urls = [
    `/klines?symbol=${pair}&interval=${tf}&limit=96`,
    `/klines-vision?symbol=${pair}&interval=${tf}&limit=96`,
    `/klines-bybit?category=spot&symbol=${pair}&interval=${BYBIT_TF[tf]}&limit=96`,
    `/klines-kucoin?type=${KUCOIN_TF[tf]}&symbol=${base}-USDT`,
  ];

  for (const url of urls) {
    try {
      const res = await fetch(url, { signal });
      if (!res.ok) continue;
      const rows = parse(await res.json());
      if (usable(rows)) return rows;
    } catch {
      // Отмена запроса — не ошибка источника: прекращаем перебор.
      if (signal?.aborted) return [];
    }
  }
  return [];
}

/** Адрес графика на TradingView для монет и акций. */
export function tradingViewUrl(sym: string): string {
  const key = String(sym || "").toUpperCase().replace(/^K/, "");
  const special: Record<string, string> = {
    NVDA: "NASDAQ:NVDA",
    INTC: "NASDAQ:INTC",
    GOOGL: "NASDAQ:GOOGL",
    GOOG: "NASDAQ:GOOG",
    HYPE: "KUCOIN:HYPEUSDT",
    PUMP: "MEXC:PUMPUSDT",
  };
  const symbol = special[key] ?? `BINANCE:${key}USDT`;
  return "https://www.tradingview.com/chart/?symbol=" + encodeURIComponent(symbol);
}
