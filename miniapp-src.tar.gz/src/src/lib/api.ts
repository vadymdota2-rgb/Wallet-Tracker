/**
 * Запросы к API мини-аппа.
 *
 * Подпись передаётся заголовком `X-Telegram-Init-Data`. Подстановки
 * `?tg=<id>` здесь нет намеренно: сервер её больше не принимает, а прежде
 * она позволяла открыть чужой аккаунт по одному номеру в адресе запроса.
 */

import type { Bootstrap } from "./types";

const TIMEOUT_MS = 15_000;

function initData(): string {
  try {
    return window.Telegram?.WebApp?.initData ?? "";
  } catch {
    return "";
  }
}

/** Код последнего ответа: 0 — сеть не ответила. */
export let lastStatus = 0;

async function request<T>(url: string, init?: RequestInit): Promise<T | null> {
  const headers = new Headers(init?.headers);
  const sig = initData();
  if (sig) headers.set("X-Telegram-Init-Data", sig);
  if (init?.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { ...init, headers, signal: ctrl.signal });
    lastStatus = res.status;
    return res.ok ? ((await res.json()) as T) : null;
  } catch {
    lastStatus = 0;
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Один запрос вместо двух. Раньше рядом шёл ещё анонимный вызов, и ответы
 * сливались — из-за чего сбой авторизации выглядел как обычные данные.
 */
export function fetchBootstrap(): Promise<Bootstrap | null> {
  return request<Bootstrap>("/api/bootstrap");
}

type Ok = { ok: boolean; error?: string; limit?: number };

const post = (path: string, body: unknown) =>
  request<Ok>(path, { method: "POST", body: JSON.stringify(body) });

export const addWallet = (addr: string, name?: string) =>
  post("/api/wallets", { addr, name });

export const removeWallet = (addr: string) =>
  post("/api/wallets/remove", { addr });

export const makePrimary = (addr: string) =>
  post("/api/wallets/primary", { addr });

export const renameWallet = (addr: string, name: string) =>
  post("/api/wallets/rename", { addr, name });

/** Границы те же, что в боте: от $50 до $1B. */
export const setThreshold = (usd: number) => post("/api/threshold", { usd });
