/**
 * Формы данных, приходящих от `whale_api.py`. Поля выписаны по реальному
 * ответу `/api/bootstrap`, а не по догадкам: см. `load_wallets`,
 * `load_coins`, `load_flow`, `load_rank` в whale_api.py.
 */

export type Plan = "free" | "premium";
export type Venue = "spot" | "perp";

/** Открытая позиция на Hyperliquid. */
export interface Position {
  sym: string;
  long: boolean;
  lev: number;
  /** Нереализованный результат в долларах. */
  pnl: number;
  /** Он же в процентах к вложенному. */
  pct: number;
  entry?: number;
  liq?: number;
  margin?: number;
  size?: number;
  /** Кросс-маржа. Изолированную обозначает `isolated`. */
  isolated?: boolean;
  funding?: number;
  /** Текущая цена. */
  now?: number;
  /** Сколько держится, готовой строкой. */
  held?: string;
}

export interface Wallet {
  id: string;
  name: string;
  addr: string;
  /** Сокращённый адрес для показа. */
  short: string;
  /** Основной кошелёк: на бесплатном плане только он шлёт алерты. */
  primary: boolean;
  /** Сводная оценка 0–100. */
  score: number;
  /** Баланс в долларах. */
  bal: number;
  trades: number;
  /** Доля прибыльных сделок, проценты. */
  win: number;
  /** Профит-фактор. */
  pf: number;
  net: number;
  /** Просадка. */
  dd: number;
  /** Место в топе строкой: "#12" либо "—". */
  spot: string;
  perp: string;
  /** Изменение за сутки, проценты. */
  d1: number;
  equity?: number;
  pos?: Position[];
}

/** Кто и на сколько торговал монету. */
export interface CoinTrader {
  /** Имя кошелька. */
  w: string;
  /** Сумма со знаком. */
  v: number;
  /** Когда, готовой строкой. */
  t: string;
}

/** Согласие крупных кошельков по монете. */
export interface Consensus {
  /** Сколько из них в топ-100. */
  top: number;
  /** Всего кошельков. */
  of: number;
  /** Когда вошёл первый, готовой строкой. */
  first: string;
  /** Что ещё держат те же кошельки. */
  also: string[];
}

export interface Coin {
  sym: string;
  price?: number;
  /** Изменение за сутки, проценты. */
  chg?: number;
  d1?: number;
  /** Капитализация и ликвидность приходят готовыми строками. */
  mcap?: string;
  liq?: string;
  addr?: string;
  net?: number;
  w?: number;
  buy?: number;
  sell?: number;
  /** Средняя цена входа китов. */
  entry?: number;
  who?: CoinTrader[];
  cons?: Consensus | null;
  /** Пути к логотипу по убыванию доверия; считается на сервере. */
  icon?: string[] | string;
}

/** Сделка в ленте. */
export interface FeedItem {
  sym: string;
  /** Имя кошелька. */
  w: string;
  /** Сумма в долларах. */
  v: number;
  /** Покупка. */
  up: boolean;
  act: string;
  /** Готовая подпись времени. */
  t: string;
}

export interface Me {
  plan: Plan;
  /** Сколько кошельков разрешено: 1 или 50. */
  limit: number;
  /** Порог алертов в долларах. */
  threshold: number;
  alertsToday: number;
  alerts30d: number;
  premUntil: number;
  lang: string;
}

export interface Bootstrap {
  ok: boolean;
  me: Me;
  wallets: Wallet[];
  coins: Record<string, Coin>;
  feed: FeedItem[];
  flow?: Record<string, unknown>;
  rot?: Record<string, unknown>;
  marketFeed?: FeedItem[];
  trades?: Record<string, unknown>;
  funding?: unknown[];
  rank?: Record<string, unknown>;
  sonar?: unknown;
  rankWindows?: number[];
  alertsToday?: number;
  alerts30d?: number;
}

/** Строка рейтинга. Поля сокращены на сервере ради размера ответа. */
export interface RankRow {
  /** Адрес. */
  a: string;
  /** Прибыль в долларах. */
  pnl: number;
  /** Доходность к вложенному, проценты. */
  roi: number;
  /** Доля прибыльных сделок, проценты. */
  win: number;
  /** Число сделок. */
  tr: number;
  /** Просадка. */
  dd: number;
  /** Активных дней из 30. */
  days: number;
  /** Средняя длительность сделки, готовой строкой. */
  hold?: string;
  /** Средний плечевой множитель. */
  lev?: number;
}

/** rank[площадка][сортировка] — список строк. */
export type RankTable = Record<string, Record<string, RankRow[]>>;

/** Итог разовой проверки чужого адреса. */
export interface WalletReport {
  score: number;
  trades: number;
  win: number;
  pf: number;
  net: number;
  dd: number;
}

/** Строка потока по монете за окно. */
export interface FlowRow {
  sym: string;
  /** Куплено и продано в долларах. */
  buy: number;
  sell: number;
  /** Разница. */
  net: number;
  /** Сколько кошельков участвовало. */
  w: number;
  /** Доля кошельков из топ-100, проценты. */
  top: number;
  /** Приток за последний час и за шесть часов — для расчёта ускорения. */
  c1: number;
  c6: number;
}

export interface FlowWindow {
  net: number;
  buy: number;
  sell: number;
  /** Сколько монет попало в окно. */
  coins: number;
  rows: FlowRow[];
}

/** Перекладывание денег: из монеты в монету. */
export interface RotationLink {
  from: string;
  to: string;
  usd: number;
  /** Сколько кошельков сделали этот переход. */
  w: number;
}

/** Строка ставки финансирования. */
export interface FundingRow {
  sym: string;
  /** Ставка в процентах. */
  rate: number;
  /** Годовая. */
  apr: number;
  /** Открытый интерес в долларах. */
  oi: number;
  /** Кто платит: готовая подпись. */
  side: string;
}

/** Сигнал Cortex. */
export interface Signal {
  sym: string;
  /** Покупка или продажа. */
  side: "buy" | "sell";
  /** Уверенность модели, проценты. */
  conf: number;
  entry: number;
  /** Рекомендуемое плечо. */
  lev: number;
  /** Риск в процентах от депозита. */
  risk: number;
  /** Окно в часах, к которому относится сигнал. */
  win?: number;
  /** Площадка. */
  venue?: "spot" | "perp";
  /** Границы, внутри которых план остаётся в силе. */
  lo?: number;
  hi?: number;
  stop?: number;
  /** Расстояние до стопа в процентах. */
  stopPct?: number;
  t1?: number;
  t2?: number;
  /** Чистый поток по монете. */
  net?: number;
  /** Сколько кошельков в потоке. */
  w?: number;
  /** Причины: ключи переводов. */
  why?: string[];
}

/** Состояние модели Cortex. */
export interface SonarState {
  /** Модель обучена, а не работает по формуле. */
  trained: boolean;
  /** Сколько результатов набрано, по площадкам. */
  ready: Record<string, number>;
  /** Сколько нужно для обучения. */
  need: number;
  /** Точность на отложенных данных, проценты. */
  acc?: number;
  list: Signal[];
  hist?: SonarHistory;
}

/** Одна закрытая проверка сигнала. */
export interface HistItem {
  sym: string;
  /** Сигнал был на покупку. */
  long: boolean;
  /** Направление угадано. */
  win: boolean;
  /** Движение цены после сигнала, проценты. */
  ret: number;
  /** Сколько прошло, готовой строкой. */
  t: string;
}

/** Сводка по истории сигналов. */
export interface SonarHistory {
  /** Доля угаданных направлений, проценты. */
  hit: number;
  /** Всего сигналов. */
  of: number;
  /** Дошли до цели и до стопа. */
  tp: number;
  sl: number;
  /** Цена ушла до входа. */
  missed: number;
  /** Пошла против сигнала. */
  broken: number;
  /** Среднее движение с сигналом, проценты. */
  avg: number;
  items: HistItem[];
}
