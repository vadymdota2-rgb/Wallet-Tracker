/**
 * Загрузка данных и опрос сервера.
 *
 * Одна цепочка вместо двух независимых: раньше рядом жили повтор каждые
 * 8 секунд при неудаче и отдельный интервал на 3 минуты — при затяжном
 * сбое запросы накладывались друг на друга.
 */

import { fetchBootstrap, lastStatus } from "./api";
import { useApp } from "../store";
import { useLive } from "../store/live";
import { LANGS } from "../i18n";
import type { LangCode } from "../i18n/types";

/** Язык, выбранный вручную, сервер не перебивает. */
function langChosenByHand(): boolean {
  try {
    return localStorage.getItem("wt.langSet") === "1";
  } catch {
    return false;
  }
}

function knownLang(code: unknown): LangCode | undefined {
  return LANGS.some((l) => l.id === code) ? (code as LangCode) : undefined;
}

const OK_DELAY = 180_000;
const FAIL_START = 8_000;
const FAIL_MAX = 60_000;

export async function pullLive(): Promise<boolean> {
  const data = await fetchBootstrap();
  if (!data) return false;

  const wallets = useLive.getState().apply(data);
  const me = data.me;

  // Язык берём тот, что человек выбрал в боте. Прежняя оболочка при
  // отсутствии ручного выбора жёстко ставила английский, из-за чего
  // русскоязычный бот открывался английской апкой.
  const fromServer = knownLang(me?.lang);

  useApp.setState((s) => ({
    lang: !langChosenByHand() && fromServer ? fromServer : s.lang,
    wallets: wallets.length ? wallets : s.wallets,
    plan: me?.plan === "premium" ? "premium" : s.plan,
    threshold: Number(me?.threshold) || s.threshold,
    premUntil: Number(me?.premUntil) || s.premUntil,
    syncedAt: Date.now(),
  }));
  return true;
}

let timer: ReturnType<typeof setTimeout> | undefined;
let delay = FAIL_START;

/** Опрос с нарастающей паузой при сбоях. Возвращает функцию остановки. */
export function startPolling(): () => void {
  const tick = async () => {
    const ok = await pullLive();
    if (ok) {
      delay = FAIL_START;
      timer = setTimeout(tick, OK_DELAY);
      return;
    }
    // 401 и 403 означают, что подписи нет и не появится: долбиться незачем.
    delay = lastStatus === 401 || lastStatus === 403 ? FAIL_MAX : Math.min(FAIL_MAX, delay * 2);
    timer = setTimeout(tick, delay);
  };

  const onVisible = () => {
    if (document.visibilityState !== "visible") return;
    clearTimeout(timer);
    timer = setTimeout(tick, 300);
  };

  void tick();
  document.addEventListener("visibilitychange", onVisible);
  return () => {
    clearTimeout(timer);
    document.removeEventListener("visibilitychange", onVisible);
  };
}
