/** Короткий отклик Telegram на действие. Вне Telegram молча ничего не делает. */
export function haptic(): void {
  try {
    window.Telegram?.WebApp?.HapticFeedback?.selectionChanged?.();
  } catch {
    /* вне Telegram отклика нет — это нормально */
  }
}
