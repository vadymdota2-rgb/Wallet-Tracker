/**
 * Форматирование чисел в стиле Binance: разряды запятой, дробная часть
 * точкой, постоянное число знаков. Локаль не зашита — раньше здесь стояла
 * жёсткая `ru-RU`, из-за чего разделителем шёл узкий пробел независимо от
 * выбранного языка.
 */

/** Разряды запятой плюс фиксированное число знаков после точки. */
export function group(value: number | string, digits: number): string {
  const [whole = "0", frac] = (Number(value) || 0).toFixed(digits).split(".");
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return frac === undefined ? grouped : grouped + "." + frac;
}

/** Компактная сумма: $1.50K, $1.23M, $2.50B. Знак не добавляется. */
export function usd(value: number): string {
  const abs = Math.abs(value);
  if (abs >= 1e9) return "$" + group(abs / 1e9, 2) + "B";
  if (abs >= 1e6) return "$" + group(abs / 1e6, 2) + "M";
  if (abs >= 1e3) return "$" + group(abs / 1e3, 2) + "K";
  return "$" + group(abs, 2);
}

/** То же, но со знаком: +$1.23M / -$1.23M. Минус обычный, не типографский. */
export function signed(value: number): string {
  return (value < 0 ? "-" : "+") + usd(value);
}

/** Полная сумма с разрядами: $1,234,567.89. */
export function full(value: number): string {
  return "$" + group(Math.abs(value), 2);
}

/** Процент со знаком, по умолчанию два знака — как на бирже. */
export function pct(value: number, digits = 2): string {
  return (value < 0 ? "-" : "+") + Math.abs(value).toFixed(digits) + "%";
}

/** Число с разрядами. Нули на конце не срезаются. */
export function num(value: number | string, digits = 2): string {
  return group(value, digits);
}

/** Цена: число знаков по величине, как шаг цены на бирже. */
export function price(value: number): string {
  const abs = Math.abs(value);
  return group(value, abs >= 1e3 ? 2 : abs >= 1 ? 4 : abs >= 0.01 ? 6 : 8);
}

/** Порог алертов подписывается так же, как в боте (alert_settings.cpp). */
export function thresholdLabel(usdValue: number): string {
  return usdValue >= 1000 && usdValue % 1000 === 0
    ? "$" + usdValue / 1000 + "K"
    : "$" + group(usdValue, 0);
}

/** Русские склонения: 1 кошелёк, 2 кошелька, 5 кошельков. */
export function plural(n: number, one: string, few: string, many: string): string {
  const i = n % 10;
  const j = n % 100;
  const word = i === 1 && j !== 11 ? one : i >= 2 && i <= 4 && (j < 12 || j > 14) ? few : many;
  return n + " " + word;
}

/** Сколько прошло: just / 1m / 42m / 7h. */
export function ago(ts: number): string {
  const sec = Math.round((Date.now() - ts) / 1e3);
  if (sec < 45) return "just";
  if (sec < 90) return "1m";
  const min = Math.round(sec / 60);
  return min < 60 ? min + "m" : Math.round(min / 60) + "h";
}

/** 0x1234…cdef */
export function shortAddr(addr: string): string {
  return addr.length < 12 ? addr : addr.slice(0, 6) + "\u2026" + addr.slice(-4);
}

export const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;
