/**
 * Трейдер из топа. Ссылка вида `<площадка>.<сортировка>.<номер>`;
 * старый формат без площадки понимается как спот.
 */

import { useApp, walletLimit } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { group, num, pct, shortAddr, signed, usd } from "../lib/format";
import { Action } from "../components/Action";
import { Blank } from "../components/Blank";
import { ScoreBar, historyKey } from "../components/ScoreBar";
import { SectionTitle } from "../components/SectionTitle";
import { Tiles } from "../components/Tiles";
import type { DictKey } from "../i18n/types";

const SORT_LABEL: Record<string, DictKey> = {
  pnl: "byPnl",
  roi: "byRoi",
  win: "byWin",
  act: "byAct",
};

/**
 * Оценка трейдера. В ответе сервера её нет — она считается здесь из
 * доли прибыльных сделок, доходности и отношения прибыли к просадке.
 */
function traderScore(win: number, roi: number, pnl: number, dd: number): number {
  const stability = dd > 0 ? Math.min(20, (pnl / dd) * 6) : 20;
  const raw = win * 0.5 + Math.min(40, roi / 10) + stability;
  return Math.max(5, Math.min(99, Math.round(raw)));
}

export function TraderScreen({ refKey }: { refKey: string }) {
  const lang = useApp((s) => s.lang);
  const wallets = useApp((s) => s.wallets);
  const plan = useApp((s) => s.plan);
  const addWallet = useApp((s) => s.addWallet);
  const rank = useLive((s) => s.rank);

  const parts = refKey.split(".");
  const venue = parts.length === 3 ? (parts[0] ?? "spot") : "spot";
  const sort = (parts.length === 3 ? parts[1] : parts[0]) ?? "pnl";
  const index = Number(parts.length === 3 ? parts[2] : parts[1]);
  const row = rank[venue]?.[sort]?.[index];

  if (!row) return <Blank title={t(lang, "titleTrader")} />;

  const already = wallets.some((w) => w.addr.toLowerCase() === row.a.toLowerCase());
  const score = traderScore(row.win, row.roi, row.pnl, row.dd);
  const limit = walletLimit(plan);

  return (
    <section className="pad">
      <SectionTitle
        title={t(lang, "titleTrader")}
        extra={t(lang, "traderN", { n: index + 1, by: t(lang, SORT_LABEL[sort] ?? "byPnl") })}
      />
      <p className="lead" style={{ wordBreak: "break-all" }}>
        {row.a}
      </p>

      <ScoreBar score={score} label={t(lang, "scoreOf", { v: t(lang, historyKey(score)) })} />

      <Tiles
        items={[
          { label: t(lang, "profit"), value: signed(row.pnl), cls: row.pnl >= 0 ? "up" : "dn" },
          { label: t(lang, "rankByRoi"), value: pct(row.roi, 0), cls: row.roi >= 0 ? "up" : "dn" },
          { label: t(lang, "accuracy"), value: `${row.win}%` },
          { label: t(lang, "trades"), value: group(row.tr, 0) },
          { label: t(lang, "drawdown"), value: "-" + usd(row.dd), cls: "dn" },
          { label: t(lang, "daysActive"), value: t(lang, "of30", { n: row.days }) },
          ...(row.hold ? [{ label: t(lang, "avgHold"), value: row.hold }] : []),
          ...(row.lev ? [{ label: t(lang, "avgLev"), value: `${row.lev}\u00d7` }] : []),
        ]}
      />

      <p className="lead">
        {t(lang, "avgTrade", {
          // Нулевое число сделок дало бы Infinity в средней прибыли.
          v: signed(row.tr > 0 ? Math.round(row.pnl / row.tr) : 0),
          r: num(row.dd > 0 ? row.pnl / row.dd : 0, 1),
        })}
      </p>

      {already ? (
        <Action disabled>{t(lang, "alreadyIn")}</Action>
      ) : (
        <Action primary onClick={() => addWallet(row.a, shortAddr(row.a))}>
          {t(lang, "followThis")}
        </Action>
      )}
      <p className="lead">{t(lang, "slotsUsed", { n: wallets.length, limit })}</p>
    </section>
  );
}
