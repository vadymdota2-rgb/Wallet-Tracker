/**
 * Одна позиция: результат, цены, размер, запас до ликвидации.
 *
 * Ссылка вида `<id кошелька>.<номер позиции>` — позиция может закрыться,
 * пока экран открыт, поэтому её отсутствие показывается отдельно.
 */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { num, pct, price, signed, usd } from "../lib/format";
import { Action } from "../components/Action";
import { Blank } from "../components/Blank";
import { CoinIcon } from "../components/CoinIcon";
import { SectionTitle } from "../components/SectionTitle";
import { Tiles } from "../components/Tiles";

/** Ближе этого запаса позиция считается опасной. */
const DANGER_PCT = 12;

export function PositionScreen({ refKey }: { refKey: string }) {
  const lang = useApp((s) => s.lang);
  const wallets = useApp((s) => s.wallets);
  const open = useApp((s) => s.open);
  const coins = useLive((s) => s.coins);

  const [walletId = "", index = ""] = refKey.split(".");
  const wallet = wallets.find((w) => w.id === walletId);
  const pos = wallet?.pos?.[Number(index)];

  if (!wallet || !pos) {
    return <Blank title={t(lang, "posClosed")} hint={t(lang, "posClosedHint")} />;
  }

  const win = pos.pnl >= 0;
  // Запас до ликвидации в процентах от текущей цены.
  const cushion =
    pos.liq && pos.now ? Math.abs((pos.now - pos.liq) / pos.now) * 100 : null;
  const danger = cushion !== null && cushion < DANGER_PCT;

  const marginKind = pos.isolated
    ? ` \u00b7 ${t(lang, "isolated")}`
    : pos.lev > 1
      ? ` \u00b7 ${t(lang, "cross")}`
      : "";

  return (
    <section className="pad">
      <SectionTitle title={pos.sym} extra={wallet.name} />

      <div className="hero">
        <CoinIcon sym={pos.sym} size={52} />
        <div>
          <div className={`n ${win ? "up" : "dn"}`}>{signed(pos.pnl)}</div>
          <div className="c" style={{ color: win ? "var(--color-up)" : "var(--color-dn)" }}>
            {pct(pos.pct)} {"\u00b7"} {pos.long ? t(lang, "long") : t(lang, "short")} {pos.lev}
            {"\u00d7"}
            {marginKind}
            {pos.held ? ` \u00b7 ${pos.held}` : ""}
          </div>
        </div>
      </div>

      <Tiles
        items={[
          { label: t(lang, "entryCap"), value: price(pos.entry ?? 0) },
          { label: t(lang, "now"), value: price(pos.now ?? 0) },
          { label: t(lang, "posSize"), value: usd(pos.size ?? 0) },
          { label: t(lang, "ownMoney"), value: usd(pos.margin ?? 0) },
          { label: t(lang, "profit"), value: signed(pos.pnl), cls: win ? "up" : "dn" },
          {
            label: t(lang, "funding"),
            value: signed(pos.funding ?? 0),
            cls: (pos.funding ?? 0) >= 0 ? "up" : "dn",
          },
        ]}
      />

      {pos.liq ? (
        <>
          <SectionTitle
            title={t(lang, "liquidation")}
            extra={t(lang, danger ? "liqClose" : "liqOk")}
          />
          <Tiles
            items={[
              { label: t(lang, "liqPrice"), value: price(pos.liq), cls: danger ? "dn" : undefined },
              {
                label: t(lang, "liqCushion"),
                value: `${num(cushion ?? 0, 1)}%`,
                cls: danger ? "dn" : undefined,
              },
            ]}
          />
          <p className="lead">
            {danger ? t(lang, "liqNear") : t(lang, "liqFar", { n: num(cushion ?? 0, 1) })}
          </p>
        </>
      ) : (
        <p className="lead">{t(lang, "noLev")}</p>
      )}

      {coins[pos.sym] ? (
        <Action extra={"\u2192"} onClick={() => open("coin", pos.sym)}>
          {t(lang, "openCoin")}
        </Action>
      ) : null}
      <Action extra={wallet.name} onClick={() => open("wallet", wallet.id)}>
        {t(lang, "toWallet")}
      </Action>
    </section>
  );
}
