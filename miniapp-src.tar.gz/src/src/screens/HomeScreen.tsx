/**
 * «Мои кошельки» — главный экран.
 *
 * Кнопка справа от кошелька разворачивает его открытые позиции. На
 * бесплатном плане вместо глаза замок: алерты идут только с основного
 * кошелька, как и в боте (см. `refreshWatchers` и premium.cpp).
 */

import { useState } from "react";
import { useApp, isPaused, walletLimit } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { pct, signed, thresholdLabel, usd } from "../lib/format";
import { Action } from "../components/Action";
import { Blank } from "../components/Blank";
import { CoinIcon } from "../components/CoinIcon";
import { Pulse } from "../components/Pulse";
import { Row } from "../components/Row";
import { SectionTitle } from "../components/SectionTitle";
import { Tiles } from "../components/Tiles";
import type { Wallet } from "../lib/types";

/** Те же ступени, что на клавиатуре бота (alert_settings.cpp). */
const STEPS = [100, 500, 1_000, 5_000, 10_000, 50_000];

export function HomeScreen() {
  const lang = useApp((s) => s.lang);
  const wallets = useApp((s) => s.wallets);
  const plan = useApp((s) => s.plan);
  const threshold = useApp((s) => s.threshold);
  const setThreshold = useApp((s) => s.setThreshold);
  const open = useApp((s) => s.open);
  const { feed, coins } = useLive();
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  if (!wallets.length) {
    return (
      <>
        <Blank title={t(lang, "homeEmpty")} hint={t(lang, "homeEmptyHint")} />
        <section className="pad">
          <Action primary onClick={() => open("add")}>
            {t(lang, "addWallet")}
          </Action>
        </section>
      </>
    );
  }

  const dayNet = wallets.reduce((sum, w) => sum + (w.bal * w.d1) / 100, 0);
  const watched = wallets.reduce((sum, w) => sum + w.bal, 0);
  const names = new Set(wallets.map((w) => w.name));
  const mine = feed.filter((f) => names.has(f.w));
  const limit = walletLimit(plan);

  return (
    <>
      <Pulse
        net={dayNet}
        caption={t(lang, "myDay", { v: usd(watched) })}
        buy={Math.max(0, dayNet)}
        sell={Math.max(0, -dayNet)}
        boughtLabel={t(lang, "bought", { v: usd(Math.max(0, dayNet)) })}
        soldLabel={t(lang, "sold", { v: usd(Math.max(0, -dayNet)) })}
      />

      <section className="pad">
        <Tiles
          items={[
            {
              label: t(lang, "walletsCount"),
              value: (
                <>
                  {wallets.length} <span className="subn">{t(lang, "ofLimit", { n: limit })}</span>
                </>
              ),
            },
            { label: t(lang, "alertThreshold"), value: thresholdLabel(threshold) },
          ]}
        />

        <div className="chips">
          {STEPS.map((step) => (
            <button
              key={step}
              type="button"
              className={`chip${threshold === step ? " on" : ""}`}
              onClick={() => setThreshold(step)}
            >
              {thresholdLabel(step)}
            </button>
          ))}
          <button type="button" className="chip more" onClick={() => open("threshold")}>
            {"\u2026"}
          </button>
        </div>

        <SectionTitle title={t(lang, "myWallets")} extra={t(lang, "perDay")} />

        {wallets.map((w) => (
          <WalletCard
            key={w.id}
            wallet={w}
            paused={isPaused(plan, w.primary)}
            expanded={!!expanded[w.id]}
            onToggle={() =>
              setExpanded((prev) => ({ ...prev, [w.id]: !prev[w.id] }))
            }
          />
        ))}

        {plan !== "premium" && wallets.length > 1 ? (
          <p className="lead">{t(lang, "freeNotice")}</p>
        ) : null}

        {mine.length ? (
          <>
            <SectionTitle title={t(lang, "lastAlert")} extra={t(lang, "byMine")} />
            {mine.map((f, i) => (
              <Row
                key={i}
                cls={f.up ? "up" : "dn"}
                ic={f.sym}
                title={f.sym}
                value={usd(f.v)}
                sub={f.w}
                extra={`${f.act} \u00b7 ${f.t}`}
                onClick={coins[f.sym] ? () => open("coin", f.sym) : undefined}
              />
            ))}
          </>
        ) : null}
      </section>
    </>
  );
}

function WalletCard({
  wallet,
  paused,
  expanded,
  onToggle,
}: {
  wallet: Wallet;
  paused: boolean;
  expanded: boolean;
  onToggle: () => void;
}) {
  const lang = useApp((s) => s.lang);
  const open = useApp((s) => s.open);
  const positions = wallet.pos ?? [];

  // Место в топе вместо адреса: адрес человеку ничего не говорит, а ранг
  // сразу показывает, стоит ли за этим кошельком следить.
  const rank = [wallet.spot, wallet.perp]
    .filter((r) => r && r !== "\u2014")
    .join(" \u00b7 ");

  return (
    <div className="wwrap">
      <div className={`wcard${wallet.d1 >= 0 ? " up" : " dn"}${paused ? " off" : ""}`}>
        <button type="button" className="wmain" onClick={() => open("wallet", wallet.id)}>
          <span className="t">
            {wallet.name}
            {wallet.primary ? <i>{t(lang, "primary")}</i> : null}
          </span>
          <span className="v">{pct(wallet.d1)}</span>
          <span className="s">{rank || wallet.short}</span>
          <span className="x">
            {usd(wallet.bal)} {"\u00b7"} {t(lang, "scoreLabel", { n: wallet.score })}
          </span>
        </button>
        <button
          type="button"
          className={`weye${expanded ? " on" : ""}`}
          title={paused ? t(lang, "lockedTitle") : t(lang, "openPos")}
          onClick={() => (paused ? open("premium") : onToggle())}
        >
          {paused ? "\u{1F512}" : "\u{1F441}"}
          {positions.length ? <i>{positions.length}</i> : null}
        </button>
      </div>

      {expanded && !paused ? (
        <div className="wpos">
          {positions.length ? (
            positions.map((p, i) => (
              <button
                key={`${p.sym}${i}`}
                type="button"
                className={`pos ico${p.pnl < 0 ? " dn" : ""}`}
                onClick={() => open("pos", `${wallet.id}.${i}`)}
              >
                <CoinIcon sym={p.sym} size={28} />
                <b>{p.sym}</b>
                <span className="p">{signed(p.pnl)}</span>
                <small>
                  {p.long ? "LONG" : "SHORT"} {p.lev}
                  {"\u00d7"}
                </small>
                <span className="q">{pct(p.pct)}</span>
              </button>
            ))
          ) : (
            <p className="lead">{t(lang, "noPosMine")}</p>
          )}
        </div>
      ) : null}
    </div>
  );
}
