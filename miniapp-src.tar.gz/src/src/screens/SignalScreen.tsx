/** Сигнал Cortex: план входа, границы, стоп, цели и причины. */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { num, price, signed } from "../lib/format";
import { Action } from "../components/Action";
import { Blank } from "../components/Blank";
import { CoinIcon } from "../components/CoinIcon";
import { SectionTitle } from "../components/SectionTitle";
import { Tiles } from "../components/Tiles";
import type { DictKey } from "../i18n/types";

/** Коды причин, приходящие с сервера, в ключи переводов. */
const WHY: Record<string, DictKey> = {
  flow: "whyFlow",
  top100: "whyTop100",
  volume: "whyVolume",
  breadth: "whyBreadth",
  accel: "whyAccel",
  topout: "whyTopOut",
  liqskew: "whyLiqSkew",
};

export function SignalScreen({ sym }: { sym: string }) {
  const lang = useApp((s) => s.lang);
  const open = useApp((s) => s.open);
  const signals = useLive((s) => s.sonar.list);
  const coins = useLive((s) => s.coins);

  const signal = signals.find((s) => s.sym === sym);
  // Сигнал живёт ограниченное время и мог истечь, пока экран открывали.
  if (!signal) return <Blank title={t(lang, "noSignal")} hint={t(lang, "noSignalHint")} />;

  const buy = signal.side === "buy";

  return (
    <section className="pad">
      <div className="hero">
        <CoinIcon sym={signal.sym} size={52} />
        <div>
          <div className={`n ${buy ? "up" : "dn"}`}>{signal.conf}%</div>
          <div className="c">
            {t(lang, buy ? "buy" : "sell")} {"\u00b7"} {signal.sym} {"\u00b7"}{" "}
            {t(lang, "confidence")}
          </div>
        </div>
      </div>

      <article className={`card ${buy ? "up" : "dn"}`}>
        <h3>
          {t(lang, "plan")} <small>{t(lang, "planRisk", { n: num(signal.risk, 1) })}</small>
        </h3>
        <dl>
          <div>
            <dt>{t(lang, "entryCap")}</dt>
            <dd>{t(lang, "entryLev", { px: price(signal.entry), lev: signal.lev })}</dd>
          </div>
          {signal.lo !== undefined && signal.hi !== undefined ? (
            <div>
              <dt>{t(lang, "whilePrice")}</dt>
              <dd>
                {price(signal.lo)} {"\u2013"} {price(signal.hi)}
              </dd>
            </div>
          ) : null}
          {signal.stop !== undefined ? (
            <div>
              <dt>{t(lang, "stop")}</dt>
              <dd>
                {price(signal.stop)}
                {signal.stopPct !== undefined ? ` (${num(signal.stopPct, 1)}%)` : ""}
              </dd>
            </div>
          ) : null}
          {signal.t1 !== undefined ? (
            <div>
              <dt>{t(lang, "target1")}</dt>
              <dd>{price(signal.t1)}</dd>
            </div>
          ) : null}
          {signal.t2 !== undefined ? (
            <div>
              <dt>{t(lang, "target2")}</dt>
              <dd>{price(signal.t2)}</dd>
            </div>
          ) : null}
        </dl>

        {signal.why?.length ? (
          <p className="why">
            {t(lang, "why")}:{" "}
            {signal.why.map((code, i) => (
              <span key={code}>
                {i ? " \u00b7 " : ""}
                <b>{WHY[code] ? t(lang, WHY[code]) : code}</b>
              </span>
            ))}
          </p>
        ) : null}
      </article>

      <p className="lead">{t(lang, "signalNote")}</p>

      <Tiles
        items={[
          {
            label: t(lang, "flow"),
            value: signed(signal.net ?? 0),
            cls: (signal.net ?? 0) >= 0 ? "up" : "dn",
          },
          { label: t(lang, "walletsCount"), value: signal.w ?? 0 },
        ]}
      />

      {coins[signal.sym] ? (
        <Action extra={"\u2192"} onClick={() => open("coin", signal.sym)}>
          {t(lang, "openCoin")}
        </Action>
      ) : null}
    </section>
  );
}
