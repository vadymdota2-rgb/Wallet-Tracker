/** Подписка: что даёт и как оплатить. Оплата уходит в чат бота. */

import { useApp } from "../store";
import { t } from "../i18n/t";
import { Action } from "../components/Action";
import type { DictKey } from "../i18n/types";

const PERKS: [DictKey, DictKey][] = [
  ["premHl", "premHlV"],
  ["premWallets", "premWalletsV"],
  ["premRank", "premRankV"],
  ["premAlerts", "premAlertsV"],
  ["premPrio", "premPrioV"],
  ["premSonar", "premSonarV"],
  ["premCheck", "premCheckV"],
];

const DAY_MS = 86_400_000;

export function PremiumScreen() {
  const lang = useApp((s) => s.lang);
  const buy = useApp((s) => s.buyPremium);
  const plan = useApp((s) => s.plan);
  const premUntil = useApp((s) => s.premUntil);

  const active = plan === "premium";
  const daysLeft = active
    ? Math.max(1, Math.ceil((premUntil - Date.now()) / DAY_MS))
    : 0;

  return (
    <section className="pad">
      <p className="lead">{t(lang, active ? "premOn" : "premLead")}</p>
      {active && premUntil > 0 ? (
        <p className="lead">{t(lang, "premDays", { n: daysLeft })}</p>
      ) : null}

      <article className="card up">
        <h3>
          {t(lang, "premName")} <small>{t(lang, "premPrice")}</small>
        </h3>
        <dl>
          {PERKS.map(([label, value]) => (
            <div key={label}>
              <dt>{t(lang, label)}</dt>
              <dd>{t(lang, value)}</dd>
            </div>
          ))}
        </dl>
      </article>

      <Action primary onClick={buy}>
        {t(lang, active ? "buyStarsRenew" : "buyStars")}
      </Action>
      <Action onClick={buy}>{t(lang, active ? "buyTonRenew" : "buyTon")}</Action>
    </section>
  );
}
