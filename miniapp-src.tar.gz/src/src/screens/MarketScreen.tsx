/**
 * Рынок: восемь разделов — поток, жара, ротация, лента, крупнейшие сделки
 * по споту и перпам, ликвидации, финансирование.
 *
 * Перпы и финансирование доступны по подписке: на замок ведёт та же
 * заглушка, что и в остальных местах.
 */

import { useMemo } from "react";
import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { pct, plural, usd } from "../lib/format";
import { CoinIcon } from "../components/CoinIcon";
import { Locked } from "../components/Locked";
import { Pulse } from "../components/Pulse";
import { Row } from "../components/Row";
import { SearchBox } from "../components/SearchBox";
import { SectionTitle } from "../components/SectionTitle";
import { Segmented } from "../components/Segmented";
import { Tiles } from "../components/Tiles";
import type { FlowRow } from "../lib/types";
import type { MarketView } from "../store";

/** Окна потока в часах. */
const WINDOWS: [number, string][] = [
  [1, "h1"], [6, "h6"], [24, "h24"], [168, "d7"], [720, "d30"],
];

/** Ускорение притока: насколько последний час быстрее среднего за шесть. */
function heatOf(row: FlowRow): { accel: number; heat: number } {
  const accel = row.c1 - row.c6 / 6;
  return { accel, heat: accel * 2 + row.top * 10 + (row.net > 0 ? 3 : -3) };
}

export function MarketScreen() {
  const lang = useApp((s) => s.lang);
  const view = useApp((s) => s.market);
  const setView = useApp((s) => s.setMarket);
  const win = useApp((s) => s.win);
  const setWin = useApp((s) => s.setWin);
  const rotWin = useApp((s) => s.rotWin);
  const setRotWin = useApp((s) => s.setRotWin);
  const sortFlow = useApp((s) => s.sortFlow);
  const setSortFlow = useApp((s) => s.setSortFlow);
  const query = useApp((s) => s.qFlow);
  const setQuery = useApp((s) => s.setQuery);
  const plan = useApp((s) => s.plan);
  const open = useApp((s) => s.open);

  const { flow, rot, coins, marketFeed, trades, funding } = useLive();
  const locked = plan !== "premium";

  const window = flow[String(win)] ?? { net: 0, buy: 0, sell: 0, coins: 0, rows: [] };

  const rows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const list = (window.rows ?? []).filter(
      (r) => !needle || r.sym.toLowerCase().includes(needle),
    );
    return [...list].sort((a, b) =>
      sortFlow === "vol"
        ? b.buy + b.sell - (a.buy + a.sell)
        : sortFlow === "w"
          ? b.w - a.w
          : Math.abs(b.net) - Math.abs(a.net),
    );
  }, [window.rows, query, sortFlow]);

  /** Жара считается по суточному и шестичасовому окнам, дубли по монете убираются. */
  const heat = useMemo(() => {
    const merged = [...(flow["24"]?.rows ?? []), ...(flow["6"]?.rows ?? [])];
    const seen = new Set<string>();
    return merged
      .filter((r) => (seen.has(r.sym) ? false : (seen.add(r.sym), true)))
      .map((r) => ({ ...r, ...heatOf(r) }))
      .sort((a, b) => b.heat - a.heat);
  }, [flow]);

  const links = rot[String(rotWin)] ?? [];
  const rotated = links.reduce((sum, l) => sum + (Number(l.usd) || 0), 0);
  const rotWallets = links.length ? Math.max(0, ...links.map((l) => Number(l.w) || 0)) : 0;

  const walletsWord = (n: number) =>
    plural(n, t(lang, "walletOne"), t(lang, "walletFew"), t(lang, "walletMany"));

  const lockScreen = (
    <Locked
      title={t(lang, "lockedTitle")}
      hint={t(lang, "lockedHint")}
      cta={t(lang, "lockedCta")}
      onClick={() => open("premium")}
    />
  );

  return (
    <>
      <Segmented<MarketView>
        scroll
        value={view}
        onChange={setView}
        items={[
          ["flow", t(lang, "tabFlow")],
          ["heat", t(lang, "tabHeat")],
          ["rot", t(lang, "tabRot")],
          ["feed", t(lang, "tabFeed")],
          ["spot", t(lang, "tabSpot")],
          ["perp", locked ? `${t(lang, "tabPerp")} \u{1F512}` : t(lang, "tabPerp")],
          ["liq", t(lang, "tabLiq")],
          ["fund", locked ? `${t(lang, "tabFund")} \u{1F512}` : t(lang, "tabFund")],
        ]}
      />

      {view === "flow" ? (
        <>
          <Pulse
            net={window.net}
            caption={t(lang, "netFlowShort", { n: window.coins })}
            buy={window.buy}
            sell={window.sell}
            boughtLabel={t(lang, "bought", { v: usd(window.buy) })}
            soldLabel={t(lang, "sold", { v: usd(window.sell) })}
          />
          <Segmented<number>
            value={win}
            onChange={setWin}
            items={WINDOWS.map(([h, key]) => [h, t(lang, key as never)])}
          />
          <section className="pad">
            {win >= 168 ? (
              <p className="lead">{t(lang, win === 720 ? "longWinMonth" : "longWinWeek")}</p>
            ) : null}
            <SearchBox
              value={query}
              onChange={(v) => setQuery("qFlow", v)}
              placeholder={t(lang, "findCoin")}
              clearLabel={t(lang, "clear")}
            />
            <Segmented
              value={sortFlow}
              onChange={setSortFlow}
              items={[
                ["net", t(lang, "sortNet")],
                ["vol", t(lang, "sortVol")],
                ["w", t(lang, "sortW")],
              ]}
            />
            {rows.length ? (
              <>
                <SectionTitle
                  title={t(lang, "byCoins")}
                  extra={t(lang, query ? "foundN" : "firstN", { n: rows.length })}
                />
                {rows.map((r) => (
                  <Row
                    key={r.sym}
                    cls={r.net >= 0 ? "up" : "dn"}
                    ic={r.sym}
                    title={r.sym}
                    value={usd(r.net)}
                    sub={walletsWord(r.w)}
                    extra={`${t(lang, "turnover")} ${usd(r.buy + r.sell)}`}
                    onClick={coins[r.sym] ? () => open("coin", r.sym) : undefined}
                  />
                ))}
              </>
            ) : (
              <p className="lead">{t(lang, "flowNone", { q: query })}</p>
            )}
          </section>
        </>
      ) : null}

      {view === "heat" ? (
        <section className="pad">
          <p className="lead">{t(lang, "heatLead")}</p>
          <SectionTitle title={t(lang, "tabHeat")} extra={t(lang, "byAccel")} />
          {heat.map((r, i) => (
            <Row
              key={r.sym}
              cls={r.net >= 0 ? "up" : "dn"}
              ic={r.sym}
              title={`${i + 1}. ${r.sym}`}
              value={usd(r.net)}
              sub={`${t(lang, "inflow")} ${usd(r.c1)}`}
              extra={`${t(lang, "top100")} ${pct(r.top, 0)} \u00b7 ${walletsWord(r.w)}`}
              onClick={coins[r.sym] ? () => open("coin", r.sym) : undefined}
            />
          ))}
          <p className="lead">{t(lang, "heatNote")}</p>
        </section>
      ) : null}

      {view === "rot" ? (
        <>
          <Segmented<number>
            value={rotWin}
            onChange={setRotWin}
            items={[
              [24, t(lang, "win24")],
              [168, t(lang, "win7d")],
            ]}
          />
          <section className="pad">
            <p className="lead">{t(lang, "rotLead")}</p>
            <Tiles
              items={[
                { label: t(lang, "rotated"), value: usd(rotated) },
                { label: t(lang, "rotWallets"), value: rotWallets },
              ]}
            />
            <SectionTitle title={t(lang, "rotFlows")} extra={String(links.length)} />
            {links.map((l) => (
              <div className="rrow" key={l.from + l.to}>
                <CoinIcon sym={l.from} size={26} />
                <span className="ar">{"\u2192"}</span>
                <CoinIcon sym={l.to} size={26} />
                <span className="rt">
                  <b>
                    {l.from} {"\u2192"} {l.to}
                  </b>
                  <em>{t(lang, "rotDid", { n: walletsWord(l.w) })}</em>
                </span>
                <span className="rv">{usd(l.usd)}</span>
              </div>
            ))}
            <p className="lead">{t(lang, "rotNote")}</p>
          </section>
        </>
      ) : null}

      {view === "feed" ? (
        <section className="pad">
          <p className="lead">{t(lang, "feedLead")}</p>
          <SectionTitle
            title={t(lang, "feedCap")}
            extra={t(lang, "updated", { t: t(lang, "justNow") })}
          />
          {marketFeed.map((f, i) => (
            <Row
              key={i}
              cls={f.up ? "up" : "dn"}
              ic={f.sym}
              title={f.sym}
              value={usd(f.v)}
              sub={f.w}
              extra={`${f.act} \u00b7 ${f.t}`}
              onClick={coins[f.sym] ? () => open("coin", f.sym) : undefined}
            />
          ))}
        </section>
      ) : null}

      {view === "spot" ? (
        <TradeList cap={t(lang, "spotCap")} lead={t(lang, "spotLead")} rows={trades.spot} />
      ) : null}

      {view === "perp" ? (
        locked ? lockScreen : (
          <TradeList cap={t(lang, "perpCap")} lead={t(lang, "perpLead")} rows={trades.perp} />
        )
      ) : null}

      {view === "liq" ? (
        <TradeList cap={t(lang, "liqCap")} lead={t(lang, "liqLead")} rows={trades.liq} />
      ) : null}

      {view === "fund" ? (
        locked ? lockScreen : (
          <section className="pad">
            <p className="lead">{t(lang, "fundLead")}</p>
            <SectionTitle title={t(lang, "fundCap")} />
            {funding.map((f) => (
              <Row
                key={f.sym}
                cls={f.rate >= 0 ? "up" : "dn"}
                ic={f.sym}
                title={f.sym}
                value={pct(f.rate, 3)}
                sub={f.side}
                extra={t(lang, "aprOi", { apr: pct(f.apr), oi: usd(f.oi) })}
              />
            ))}
          </section>
        )
      ) : null}
    </>
  );
}

/** Список крупнейших сделок раздела. */
function TradeList({ cap, lead, rows }: { cap: string; lead: string; rows?: import("../lib/types").FeedItem[] }) {
  const coins = useLive((s) => s.coins);
  const open = useApp((s) => s.open);
  return (
    <section className="pad">
      <p className="lead">{lead}</p>
      <SectionTitle title={cap} extra={String(rows?.length ?? 0)} />
      {(rows ?? []).map((f, i) => (
        <Row
          key={i}
          cls={f.up ? "up" : "dn"}
          ic={f.sym}
          title={f.sym}
          value={usd(f.v)}
          sub={f.w}
          extra={`${f.act} \u00b7 ${f.t}`}
          onClick={coins[f.sym] ? () => open("coin", f.sym) : undefined}
        />
      ))}
    </section>
  );
}
