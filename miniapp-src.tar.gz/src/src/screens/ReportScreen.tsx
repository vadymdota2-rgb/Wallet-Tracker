/**
 * Разовый отчёт по чужому адресу за 90 дней. Кошелёк не отслеживается,
 * алертов не будет — только показатели и предложение добавить.
 */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { group, num, shortAddr, signed, usd } from "../lib/format";
import { Action } from "../components/Action";
import { Blank } from "../components/Blank";
import { ScoreBar, historyKey } from "../components/ScoreBar";
import { SectionTitle } from "../components/SectionTitle";
import { Tiles } from "../components/Tiles";

export function ReportScreen({ addr }: { addr: string }) {
  const lang = useApp((s) => s.lang);
  const addWallet = useApp((s) => s.addWallet);
  const report = useLive((s) => s.reports[addr.toLowerCase()]);

  if (!report) {
    return <Blank title={t(lang, "titleReport")} hint={t(lang, "learning")} />;
  }

  return (
    <section className="pad">
      <SectionTitle title={t(lang, "titleReport")} extra={t(lang, "days90")} />
      <p className="lead" style={{ wordBreak: "break-all" }}>
        {addr}
      </p>
      <p className="lead">{t(lang, "reportLead")}</p>

      <ScoreBar
        score={report.score}
        label={t(lang, "scoreOf", { v: t(lang, historyKey(report.score)) })}
      />

      <Tiles
        items={[
          { label: t(lang, "trades"), value: group(report.trades, 0) },
          { label: t(lang, "accuracy"), value: `${num(report.win, 1)}%` },
          {
            label: t(lang, "profitFactor"),
            value: num(report.pf),
            cls: report.pf >= 1.5 ? "up" : report.pf >= 1 ? undefined : "dn",
          },
          { label: t(lang, "profit"), value: signed(report.net), cls: report.net >= 0 ? "up" : "dn" },
          { label: t(lang, "drawdown"), value: "-" + usd(report.dd), cls: "dn" },
        ]}
      />

      <Action primary onClick={() => addWallet(addr, shortAddr(addr))}>
        {t(lang, "addThis")}
      </Action>
    </section>
  );
}
