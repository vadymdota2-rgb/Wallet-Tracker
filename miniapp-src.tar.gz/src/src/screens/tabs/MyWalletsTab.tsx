/** Список своих кошельков с поиском, порог алертов и переход к позициям. */

import { useApp, isPaused, walletLimit } from "../../store";
import { useLive } from "../../store/live";
import { t } from "../../i18n/t";
import { pct, thresholdLabel, usd } from "../../lib/format";
import { Action } from "../../components/Action";
import { Blank } from "../../components/Blank";
import { Row } from "../../components/Row";
import { SearchBox } from "../../components/SearchBox";
import { SectionTitle } from "../../components/SectionTitle";

export function MyWalletsTab() {
  const lang = useApp((s) => s.lang);
  const wallets = useApp((s) => s.wallets);
  const threshold = useApp((s) => s.threshold);
  const plan = useApp((s) => s.plan);
  const open = useApp((s) => s.open);
  const query = useApp((s) => s.qMine);
  const setQuery = useApp((s) => s.setQuery);
  // Число алертов за 30 дней раньше было зашито числом 194 — одна и та же
  // цифра показывалась всем. Берём её из ответа сервера.
  const alerts30d = useLive((s) => s.alerts30d);

  const limit = walletLimit(plan);

  if (!wallets.length) {
    return (
      <>
        <Blank title={t(lang, "noWallets")} hint={t(lang, "noWalletsHint")} />
        <section className="pad">
          <Action primary onClick={() => open("add")}>
            {t(lang, "addWallet")}
          </Action>
        </section>
      </>
    );
  }

  const needle = query.trim().toLowerCase();
  const shown = wallets.filter(
    (w) =>
      !needle ||
      w.name.toLowerCase().includes(needle) ||
      w.addr.toLowerCase().includes(needle),
  );

  return (
    <section className="pad">
      <SearchBox
        value={query}
        onChange={(v) => setQuery("qMine", v)}
        placeholder={t(lang, "findWallet")}
        clearLabel={t(lang, "clear")}
      />
      <SectionTitle title={t(lang, "watchCap")} extra={`${shown.length} / ${limit}`} />
      {shown.map((w) => (
        <Row
          key={w.id}
          cls={w.d1 >= 0 ? "up" : "dn"}
          title={w.name}
          tag={
            w.primary
              ? t(lang, "primary")
              : isPaused(plan, w.primary)
                ? t(lang, "paused")
                : undefined
          }
          value={pct(w.d1)}
          sub={w.short}
          extra={`${usd(w.bal)} \u00b7 ${t(lang, "scoreLabel", { n: w.score })}`}
          onClick={() => open("wallet", w.id)}
        />
      ))}

      <Action primary onClick={() => open("add")}>
        {t(lang, "addWallet")}
      </Action>
      <Action extra={"\u2192"} onClick={() => open("positions")}>
        {t(lang, "hlPositions")}
      </Action>

      <SectionTitle title={t(lang, "alertsCap")} />
      <Action extra={thresholdLabel(threshold)} onClick={() => open("threshold")}>
        {t(lang, "alertThreshold")}
      </Action>
      <p className="lead">{t(lang, "alertLead", { n: alerts30d })}</p>

      {plan !== "premium" && wallets.length > 1 ? (
        <p className="lead">{t(lang, "freeNotice")}</p>
      ) : null}
    </section>
  );
}
