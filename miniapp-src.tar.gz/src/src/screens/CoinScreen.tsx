/** Монета: цена, график, поток, согласие крупных кошельков, кто торговал. */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { pct, price, signed, usd } from "../lib/format";
import { Blank } from "../components/Blank";
import { Chart } from "../components/Chart";
import { CoinIcon } from "../components/CoinIcon";
import { Row } from "../components/Row";
import { SectionTitle } from "../components/SectionTitle";
import { Segmented } from "../components/Segmented";
import { Tiles } from "../components/Tiles";
import type { DictKey } from "../i18n/types";

/** Подпись шага свечей для выбранного окна. */
const STEP: Record<string, DictKey> = {
  "1h": "step1h",
  "24h": "step24h",
  "7d": "step7d",
  "30d": "step30d",
};

/** Сколько независимых кошельков считать сильным согласием. */
const STRONG = 8;
const MODERATE = 4;

export function CoinScreen({ sym }: { sym: string }) {
  const lang = useApp((s) => s.lang);
  const open = useApp((s) => s.open);
  const tf = useApp((s) => s.tf);
  const setTf = useApp((s) => s.setTf);
  const coins = useLive((s) => s.coins);

  const coin = coins[sym] ?? coins[sym.toUpperCase()];
  // Монеты может не быть в наборе: её никто из отслеживаемых не трогал.
  if (!coin) return <Blank title={t(lang, "noCoin")} hint={t(lang, "noCoinHint")} />;

  const cons = coin.cons;
  const consKey: DictKey = !cons
    ? "consWeak"
    : cons.top >= STRONG
      ? "consStrong"
      : cons.top >= MODERATE
        ? "consMid"
        : "consWeak";

  const who = coin.who ?? [];

  return (
    <section className="pad">
      <div className="hero">
        <CoinIcon sym={sym} size={52} />
        <div>
          <div className="n">{price(coin.price ?? 0)}</div>
          <div
            className="c"
            style={{ color: (coin.chg ?? 0) >= 0 ? "var(--color-up)" : "var(--color-dn)" }}
          >
            {t(lang, "dayChg", { sym, pct: pct(coin.chg ?? 0) })}
          </div>
        </div>
      </div>

      <Segmented
        value={tf}
        onChange={setTf}
        items={[
          ["1h", t(lang, "tf1h")],
          ["24h", t(lang, "tf24h")],
          ["7d", t(lang, "tf7d")],
          ["30d", t(lang, "tf30d")],
        ]}
      />

      <Chart
        sym={sym}
        window={tf}
        entry={coin.entry}
        note={(n) => t(lang, "candlesNote", { n, step: t(lang, STEP[tf] ?? "step24h") })}
      />

      <Tiles
        items={[
          {
            label: t(lang, "netFlowTile"),
            value: signed(coin.net ?? 0),
            cls: (coin.net ?? 0) >= 0 ? "up" : "dn",
          },
          { label: t(lang, "walletsCount"), value: coin.w ?? 0 },
          { label: t(lang, "boughtCap"), value: usd(coin.buy ?? 0) },
          { label: t(lang, "soldCap"), value: usd(coin.sell ?? 0) },
          { label: t(lang, "mcap"), value: coin.mcap ?? "\u2014" },
          { label: t(lang, "liq"), value: coin.liq ?? "\u2014" },
        ]}
      />

      {cons ? (
        <>
          <SectionTitle title={t(lang, "consensus")} extra={t(lang, "consTop", { n: cons.top })} />
          <div className="cons">
            <div className="dots">
              {Array.from({ length: Math.min(24, cons.of) }, (_, i) => (
                <i key={i} className={i < cons.top ? "on" : undefined} />
              ))}
            </div>
            <p className="lead">
              {t(lang, "consLead", {
                top: cons.top,
                rest: cons.of - cons.top,
                first: cons.first,
              })}{" "}
              {t(lang, consKey)}
            </p>
            {cons.also.length ? (
              <p className="lead">
                {t(lang, "consAlso")}{" "}
                {cons.also.map((other, i) => (
                  <span key={other}>
                    {i ? " \u00b7 " : null}
                    {coins[other] ? (
                      <button type="button" className="lnk" onClick={() => open("coin", other)}>
                        {other}
                      </button>
                    ) : (
                      other
                    )}
                  </span>
                ))}
              </p>
            ) : null}
          </div>
        </>
      ) : null}

      <SectionTitle title={t(lang, "whoTraded")} extra={String(who.length)} />
      {who.map((trader, i) => (
        <Row
          key={i}
          cls={trader.v >= 0 ? "up" : "dn"}
          title={trader.w}
          value={signed(trader.v)}
          extra={t(lang, "ago", { t: trader.t })}
        />
      ))}
    </section>
  );
}
