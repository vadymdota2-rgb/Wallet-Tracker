/** Все открытые позиции по всем кошелькам. Раздел по подписке. */

import { useApp } from "../store";
import { t } from "../i18n/t";
import { pct, signed } from "../lib/format";
import { CoinIcon } from "../components/CoinIcon";
import { Locked } from "../components/Locked";
import { Row } from "../components/Row";
import { SectionTitle } from "../components/SectionTitle";

export function PositionsScreen() {
  const lang = useApp((s) => s.lang);
  const plan = useApp((s) => s.plan);
  const wallets = useApp((s) => s.wallets);
  const open = useApp((s) => s.open);

  if (plan !== "premium") {
    return (
      <Locked
        title={t(lang, "lockedTitle")}
        hint={t(lang, "lockedPos")}
        cta={t(lang, "lockedCta")}
        onClick={() => open("premium")}
      />
    );
  }

  const all = wallets.flatMap((w) =>
    (w.pos ?? []).map((p, i) => ({ ...p, who: w.name, wid: w.id, pi: i })),
  );

  return (
    <section className="pad">
      <p className="lead">{t(lang, "posPick")}</p>
      <SectionTitle title={t(lang, "openPos")} extra={String(all.length)} />
      {all.length ? (
        all.map((p) => (
          <button
            key={`${p.wid}${p.sym}${p.pi}`}
            type="button"
            className={`pos ico${p.pnl < 0 ? " dn" : ""}`}
            onClick={() => open("pos", `${p.wid}.${p.pi}`)}
          >
            <CoinIcon sym={p.sym} size={28} />
            <b>{p.sym}</b>
            <span className="p">{signed(p.pnl)}</span>
            <small>
              {p.who} {"\u00b7"} {p.long ? t(lang, "long") : t(lang, "short")} {p.lev}
              {"\u00d7"}
              {p.cross === false ? ` \u00b7 ${t(lang, "isolated")}` : p.lev > 1 ? ` \u00b7 ${t(lang, "cross")}` : ""}
            </small>
            <span className="q">{pct(p.pct)}</span>
          </button>
        ))
      ) : (
        <p className="lead">{t(lang, "noPosMine")}</p>
      )}

      <SectionTitle title={t(lang, "myWallets")} extra={String(wallets.length)} />
      {wallets.map((w) => {
        const n = (w.pos ?? []).length;
        return (
          <Row
            key={w.id}
            title={w.name}
            value={String(n)}
            sub={w.short}
            extra={n ? t(lang, "openCount") : t(lang, "noPos")}
            onClick={() => open("wallet", w.id)}
          />
        );
      })}
    </section>
  );
}
