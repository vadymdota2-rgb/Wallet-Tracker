/** Добавление кошелька: адрес и имя для алертов. */

import { useState } from "react";
import { useApp, walletLimit } from "../store";
import { t } from "../i18n/t";
import { ADDR_RE } from "../lib/format";
import { Action } from "../components/Action";

export function AddWalletScreen() {
  const lang = useApp((s) => s.lang);
  const addWallet = useApp((s) => s.addWallet);
  const wallets = useApp((s) => s.wallets);
  const plan = useApp((s) => s.plan);
  const [addr, setAddr] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const limit = walletLimit(plan);
  const free = Math.max(0, limit - wallets.length);

  const submit = () => {
    if (!ADDR_RE.test(addr.trim())) {
      setError(t(lang, "addrErr"));
      return;
    }
    setError("");
    addWallet(addr, name);
  };

  return (
    <section className="pad">
      <p className="lead">{t(lang, "addLead")}</p>
      <label className="field">
        <span>{t(lang, "addrLabel")}</span>
        <input
          value={addr}
          onChange={(e) => setAddr(e.target.value)}
          placeholder={"0x\u2026"}
          autoCapitalize="off"
          autoComplete="off"
          spellCheck={false}
        />
      </label>
      <label className="field">
        <span>{t(lang, "nickLabel")}</span>
        <input
          value={name}
          maxLength={24}
          onChange={(e) => setName(e.target.value)}
          placeholder={t(lang, "nickPh")}
        />
      </label>
      {error ? <p className="err">{error}</p> : null}
      <Action primary onClick={submit}>
        {t(lang, "addBtn")}
      </Action>
      <p className="lead">{t(lang, "freeSlots", { n: free, limit })}</p>
    </section>
  );
}
