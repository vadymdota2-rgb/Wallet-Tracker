/**
 * Cortex: сигналы, их история и описание модели.
 *
 * Сигналы фильтруются по площадке, окну и стороне — по полям самого
 * сигнала. В бандле здесь стоял отбор по списку тикеров (`BTC`, `SOL`,
 * `CAKE`, `HYPE`) в зависимости от окна, то есть имитация, а не фильтр.
 */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { num, price } from "../lib/format";
import { Locked } from "../components/Locked";
import { Row } from "../components/Row";
import { SectionTitle } from "../components/SectionTitle";
import { Segmented } from "../components/Segmented";
import { HistoryScreen } from "./HistoryScreen";
import { ModelScreen } from "./ModelScreen";
import type { SonarView } from "../store";
import type { Venue } from "../lib/types";

export function SonarScreen() {
  const lang = useApp((s) => s.lang);
  const view = useApp((s) => s.sonar);
  const setView = useApp((s) => s.setSonar);
  const venue = useApp((s) => s.venue);
  const setVenue = useApp((s) => s.setVenue);
  const win = useApp((s) => s.sonarWin);
  const setWin = useApp((s) => s.setSonarWin);
  const side = useApp((s) => s.sonarSide);
  const setSide = useApp((s) => s.setSonarSide);
  const plan = useApp((s) => s.plan);
  const open = useApp((s) => s.open);
  const sonar = useLive((s) => s.sonar);

  const premium = plan === "premium";
  const venueLocked = venue === "perp" && !premium;
  const historyLocked = view === "history" && !premium;

  const ready = sonar.ready[venue] ?? 0;
  const progress = sonar.need > 0 ? Math.min(100, (ready / sonar.need) * 100) : 100;

  const signals = sonar.list.filter((s) => {
    if (s.venue && s.venue !== venue) return false;
    if (s.win && s.win !== win) return false;
    // Сторона выбирается только на перпах: на споте продавать нечего.
    if (venue === "perp" && s.side !== (side === "short" ? "sell" : "buy")) return false;
    return true;
  });

  const lock = (hint: "lockedCortex" | "lockedHist") => (
    <Locked
      title={t(lang, "lockedTitle")}
      hint={t(lang, hint)}
      cta={t(lang, "lockedCta")}
      onClick={() => open("premium")}
    />
  );

  return (
    <>
      <Segmented<SonarView>
        value={view}
        onChange={setView}
        items={[
          ["signals", t(lang, "signals")],
          ["history", t(lang, "historyShort")],
          ["model", t(lang, "model")],
        ]}
      />
      <Segmented<Venue>
        value={venue}
        onChange={setVenue}
        items={[
          ["spot", t(lang, "venueSpot")],
          ["perp", premium ? t(lang, "venuePerp") : `${t(lang, "venuePerp")} \u{1F512}`],
        ]}
      />
      {venue === "perp" && premium ? (
        <Segmented
          value={side}
          onChange={setSide}
          items={[
            ["long", t(lang, "long")],
            ["short", t(lang, "short")],
          ]}
        />
      ) : null}
      <Segmented<number>
        value={win}
        onChange={setWin}
        items={[
          [1, t(lang, "win1")],
          [6, t(lang, "win6")],
          [24, t(lang, "win24")],
        ]}
      />

      {venueLocked ? lock("lockedCortex") : null}

      {!venueLocked && view === "signals" ? (
        <section className="pad">
          <p className="core-cap">
            {t(lang, "coreCap")} <b>{"\u2192"}</b> {t(lang, "oneScoreCap")}
          </p>
          <p className="lead">{t(lang, "sonarLead")}</p>

          {sonar.trained ? null : (
            <>
              <p className="lead">
                {t(lang, "sonarLearnA")} <b>{ready}</b> {t(lang, "sonarLearnB", { n: sonar.need })}
              </p>
              <div className="bar">
                <i style={{ width: `${progress.toFixed(0)}%` }} />
              </div>
            </>
          )}

          <SectionTitle title={t(lang, "signals")} extra={t(lang, "ofFive", { n: signals.length })} />
          {signals.length ? (
            signals.map((s, i) => (
              <Row
                key={s.sym}
                cls={s.side === "buy" ? "up" : "dn"}
                ic={s.sym}
                title={`${i + 1}. ${s.sym}`}
                tag={t(lang, s.side === "buy" ? "long" : "short")}
                value={`${s.conf}%`}
                sub={`${t(lang, "entry", { v: price(s.entry) })} \u00b7 ${t(lang, "lev", { n: s.lev })}`}
                extra={t(lang, "risk", { n: num(s.risk, 1) })}
                onClick={() => open("signal", s.sym)}
              />
            ))
          ) : (
            <p className="lead">{t(lang, "emptySonar")}</p>
          )}
        </section>
      ) : null}

      {!venueLocked && view === "history" ? (historyLocked ? lock("lockedHist") : <HistoryScreen />) : null}
      {!venueLocked && view === "model" ? <ModelScreen /> : null}
    </>
  );
}
