/** Вкладка «Трейдеры»: свои кошельки, топ-100, проверка чужого адреса. */

import { useApp } from "../store";
import { t } from "../i18n/t";
import { Segmented } from "../components/Segmented";
import { MyWalletsTab } from "./tabs/MyWalletsTab";
import { TopTradersTab } from "./tabs/TopTradersTab";
import { AnalyzeScreen } from "./AnalyzeScreen";
import type { PeopleView } from "../store";

export function PeopleScreen() {
  const lang = useApp((s) => s.lang);
  const view = useApp((s) => s.people);
  const setView = useApp((s) => s.setPeople);

  return (
    <>
      <Segmented<PeopleView>
        value={view}
        onChange={setView}
        items={[
          ["mine", t(lang, "tabMine")],
          ["top", t(lang, "tabTop")],
          ["check", t(lang, "tabCheck")],
        ]}
      />
      {view === "mine" ? <MyWalletsTab /> : null}
      {view === "top" ? <TopTradersTab /> : null}
      {view === "check" ? <AnalyzeScreen /> : null}
    </>
  );
}
