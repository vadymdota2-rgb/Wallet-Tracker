/**
 * Карточка кошелька: оценка, показатели, место в топе, открытые позиции,
 * переименование и удаление.
 */

import { useState } from "react";
import { useApp, isPaused } from "../store";
import { t } from "../i18n/t";
import { full, group, num, pct, signed, usd } from "../lib/format";
import { Action } from "../components/Action";
import { Blank } from "../components/Blank";
import { CoinIcon } from "../components/CoinIcon";
import { ScoreBar, historyKey } from "../components/ScoreBar";
import { SectionTitle } from "../components/SectionTitle";
import { Tiles } from "../components/Tiles";

export function WalletScreen({ id }: { id: string }) {
  const lang = useApp((s) => s.lang);
  const wallets = useApp((s) => s.wallets);
  const plan = useApp((s) => s.plan);
  const open = useApp((s) => s.open);
  const setPrimary = useApp((s) => s.setPrimary);
  const removeWallet = useApp((s) => s.removeWallet);
  const renaming = useApp((s) => s.renaming);
  const setRenaming = useApp((s) => s.setRenaming);
  const renameWallet = useApp((s) => s.renameWallet);

  const [draftName, setDraftName] = useState("");
  const [confirmRemove, setConfirmRemove] = useState(false);

  const wallet = wallets.find((w) => w.id === id);
  if (!wallet) return <Blank title={t(lang, "titleWallet")} />;

  const paused = isPaused(plan, wallet.primary);
  const positions = wallet.pos ?? [];

  if (confirmRemove) {
    return (
      <section className="pad">
        <p className="lead">{t(lang, "confirmRemove")}</p>
        <p className="lead" style={{ wordBreak: "break-all" }}>
          <b>{wallet.name}</b>
          <br />
          {wallet.addr}
        </p>
        <Action danger onClick={() => removeWallet(wallet.id)}>
          {t(lang, "confirmYes")}
        </Action>
        <Action onClick={() => setConfirmRemove(false)}>{t(lang, "confirmNo")}</Action>
      </section>
    );
  }

  return (
    <section className="pad">
      <SectionTitle
        title={wallet.name.toUpperCase()}
        extra={wallet.primary ? t(lang, "primary") : paused ? t(lang, "paused") : ""}
      />
      <p className="lead" style={{ wordBreak: "break-all" }}>
        {wallet.addr}
      </p>
      {paused ? <p className="lead">{t(lang, "pausedHint")}</p> : null}

      <ScoreBar
        score={wallet.score}
        label={t(lang, "scoreOf", { v: t(lang, historyKey(wallet.score)) })}
      />
      <p className="lead">{t(lang, "scoreLead")}</p>

      <Tiles
        items={[
          { label: t(lang, "balance"), value: full(wallet.bal) },
          { label: t(lang, "trades"), value: group(wallet.trades, 0) },
          { label: t(lang, "accuracy"), value: `${num(wallet.win, 1)}%` },
          {
            label: t(lang, "profitFactor"),
            value: num(wallet.pf),
            cls: wallet.pf >= 1.5 ? "up" : wallet.pf >= 1 ? undefined : "dn",
          },
          {
            label: t(lang, "profit"),
            value: signed(wallet.net),
            // Прежде здесь всегда стоял зелёный цвет, даже при убытке.
            cls: wallet.net >= 0 ? "up" : "dn",
          },
          { label: t(lang, "drawdown"), value: "-" + usd(wallet.dd), cls: "dn" },
        ]}
      />

      <SectionTitle title={t(lang, "rankPlace")} extra={t(lang, "days30")} />
      <Tiles
        items={[
          { label: t(lang, "venueSpot"), value: wallet.spot },
          { label: t(lang, "venuePerp"), value: wallet.perp },
        ]}
      />

      <SectionTitle title={t(lang, "openPos")} extra={String(positions.length)} />
      {positions.length ? (
        positions.map((p, i) => (
          <button
            key={`${p.sym}${i}`}
            type="button"
            className={`pos ico${p.pnl < 0 ? " dn" : ""}`}
            onClick={() => open("pos", `${wallet.id}.${i}`)}
          >
            <CoinIcon sym={p.sym} size={28} />
            <b>{p.sym}</b>
            <span className="p">{signed(p.pnl)}</span>
            <small>
              {p.long ? t(lang, "long") : t(lang, "short")} {"\u00b7"} {p.lev}
              {"\u00d7"} {"\u00b7"} {usd(p.size ?? 0)}
              {p.isolated ? ` \u00b7 ${t(lang, "isolated")}` : p.lev > 1 ? ` \u00b7 ${t(lang, "cross")}` : ""}
            </small>
            <span className="q">{pct(p.pct)}</span>
          </button>
        ))
      ) : (
        <p className="lead">{t(lang, "noPos")}</p>
      )}

      {wallet.primary ? null : (
        <Action onClick={() => setPrimary(wallet.id)}>{t(lang, "makePrimary")}</Action>
      )}

      {renaming === wallet.id ? (
        <>
          <label className="field">
            <span>{t(lang, "nickLabel")}</span>
            <input
              value={draftName}
              maxLength={24}
              onChange={(e) => setDraftName(e.target.value)}
              autoFocus
            />
          </label>
          <Action primary onClick={() => renameWallet(wallet.id, draftName || wallet.name)}>
            {t(lang, "save")}
          </Action>
        </>
      ) : (
        <Action
          onClick={() => {
            setDraftName(wallet.name);
            setRenaming(wallet.id);
          }}
        >
          {t(lang, "rename")}
        </Action>
      )}

      <Action danger onClick={() => setConfirmRemove(true)}>
        {t(lang, "remove")}
      </Action>
    </section>
  );
}
