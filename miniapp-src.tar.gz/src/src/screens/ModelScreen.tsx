/**
 * Как работает модель Cortex: сколько результатов набрано по каждой
 * площадке и обучена ли она.
 */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { SectionTitle } from "../components/SectionTitle";
import type { DictKey } from "../i18n/types";

export function ModelScreen() {
  const lang = useApp((s) => s.lang);
  const sonar = useLive((s) => s.sonar);

  const block = (title: DictKey, venue: "spot" | "perp") => {
    const ready = sonar.ready[venue] ?? 0;
    const share = sonar.need > 0 ? Math.min(100, (ready / sonar.need) * 100) : 100;
    // Обученность отслеживается по площадкам, а не одним флагом на обе:
    // прежняя версия для перпов всегда показывала «не обучена».
    const trained = sonar.trained && ready >= sonar.need;
    return (
      <div key={venue}>
        <SectionTitle title={t(lang, title)} extra={`${ready} / ${sonar.need}`} />
        <div className="bar">
          <i style={{ width: `${share.toFixed(0)}%` }} />
        </div>
        <p className="lead">
          {trained && sonar.acc
            ? t(lang, "trainedNote", { acc: sonar.acc })
            : t(lang, "notTrained")}
        </p>
      </div>
    );
  };

  return (
    <section className="pad">
      <p className="lead">{t(lang, "modelLead")}</p>
      {block("spotCap2", "spot")}
      {block("perpCap2", "perp")}
      <p className="lead">{t(lang, "needMore", { n: sonar.need })}</p>
    </section>
  );
}
