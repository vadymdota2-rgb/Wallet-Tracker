/**
 * Экраны, открываемые поверх вкладки, и заголовки для шапки.
 * Имя экрана кладётся в стек через `open(name, arg)`.
 */

import type { DictKey } from "../i18n/types";

export type TabName = "home" | "market" | "people" | "sonar";

export type ScreenName =
  | "coin" | "signal" | "wallet" | "pos" | "trader"
  | "add" | "analyze" | "report" | "history" | "model"
  | "threshold" | "premium" | "lang" | "help" | "positions";

/** Заголовок в шапке для вкладки или открытого экрана. */
export const TITLE: Record<TabName | ScreenName, DictKey> = {
  home: "titleHome",
  market: "titleMarket",
  people: "titlePeople",
  sonar: "titleSonar",
  coin: "titleCoin",
  signal: "titleSignal",
  wallet: "titleWallet",
  pos: "titlePos",
  trader: "titleTrader",
  add: "titleAdd",
  analyze: "titleAnalyze",
  report: "titleReport",
  history: "titleHistory",
  model: "titleModel",
  threshold: "titleThreshold",
  premium: "titlePremium",
  lang: "titleLang",
  help: "titleHelp",
  positions: "titlePositions",
};
