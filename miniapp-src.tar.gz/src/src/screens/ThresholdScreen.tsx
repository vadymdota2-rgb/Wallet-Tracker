/** Порог алертов: ступени как в боте плюс произвольная сумма. */

import { useState } from "react";
import { useApp, MIN_THRESHOLD } from "../store";
import { t } from "../i18n/t";
import { thresholdLabel } from "../lib/format";
import { Action } from "../components/Action";
import { SectionTitle } from "../components/SectionTitle";

/** Совпадает с PRESETS_USD в alert_settings.cpp. */
const PRESETS = [100, 500, 1_000, 5_000, 10_000, 50_000];

export function ThresholdScreen() {
  const lang = useApp((s) => s.lang);
  const threshold = useApp((s) => s.threshold);
  const setThreshold = useApp((s) => s.setThreshold);
  const [own, setOwn] = useState("");

  const saveOwn = () => {
    const value = parseFloat(own.replace(",", "."));
    // Раньше сюда уходил NaN при пустом поле: проверка `< 50` его
    // пропускала, и запрос улетал с мусором.
    if (!Number.isFinite(value)) return;
    setThreshold(value);
  };

  return (
    <section className="pad">
      <p className="lead">{t(lang, "thrLead")}</p>
      <SectionTitle
        title={t(lang, "thrCap")}
        extra={t(lang, "thrNow", { v: thresholdLabel(threshold) })}
      />
      {PRESETS.map((step) => (
        <Action key={step} primary={step === threshold} onClick={() => setThreshold(step)}>
          {thresholdLabel(step)}
        </Action>
      ))}
      <label className="field">
        <span>{t(lang, "ownThr")}</span>
        <input
          inputMode="decimal"
          placeholder={String(MIN_THRESHOLD * 150)}
          value={own}
          onChange={(e) => setOwn(e.target.value)}
        />
      </label>
      <Action onClick={saveOwn}>{t(lang, "save")}</Action>
    </section>
  );
}
