/** Разовая проверка чужого адреса: 90 дней, без слежения и алертов. */

import { useState } from "react";
import { useApp } from "../store";
import { t } from "../i18n/t";
import { ADDR_RE } from "../lib/format";
import { Action } from "../components/Action";

export function AnalyzeScreen() {
  const lang = useApp((s) => s.lang);
  const open = useApp((s) => s.open);
  const [addr, setAddr] = useState("");
  const [error, setError] = useState("");

  const check = () => {
    const clean = addr.trim();
    if (!ADDR_RE.test(clean)) {
      setError(t(lang, "addrErr"));
      return;
    }
    setError("");
    open("report", clean);
  };

  return (
    <section className="pad">
      <p className="lead">{t(lang, "analyzeLead")}</p>
      <label className="field">
        <span>{t(lang, "addr")}</span>
        <input
          value={addr}
          onChange={(e) => setAddr(e.target.value)}
          placeholder={"0x\u2026"}
          autoCapitalize="off"
          autoComplete="off"
          spellCheck={false}
        />
      </label>
      {error ? <p className="err">{error}</p> : null}
      <Action primary onClick={check}>
        {t(lang, "check90")}
      </Action>
      <p className="lead">{t(lang, "analyzeHint")}</p>
    </section>
  );
}
