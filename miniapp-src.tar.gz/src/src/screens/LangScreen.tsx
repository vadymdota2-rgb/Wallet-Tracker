/** Выбор языка. Шестнадцать штук, ручной выбор запоминается. */

import { useApp } from "../store";
import { t } from "../i18n/t";
import { LANGS } from "../i18n";
import { Action } from "../components/Action";
import { SectionTitle } from "../components/SectionTitle";

export function LangScreen() {
  const lang = useApp((s) => s.lang);
  const setLang = useApp((s) => s.setLang);
  const back = useApp((s) => s.back);

  return (
    <section className="pad">
      <SectionTitle title={t(lang, "langCap")} extra={t(lang, "langAvail")} />
      {LANGS.map((item) => (
        <Action
          key={item.id}
          primary={item.id === lang}
          onClick={() => {
            setLang(item.id);
            back();
          }}
        >
          {item.name}
        </Action>
      ))}
    </section>
  );
}
