/** Короткое описание разделов и правил подписки. */

import { useApp } from "../store";
import { t } from "../i18n/t";
import { SectionTitle } from "../components/SectionTitle";

const BLOCKS = [
  ["helpWalletsT", "helpWalletsB"],
  ["helpMarketT", "helpMarketB"],
  ["helpCortexT", "helpCortexB"],
  ["helpNumsT", "helpNumsB"],
] as const;

export function HelpScreen() {
  const lang = useApp((s) => s.lang);
  return (
    <section className="pad">
      <SectionTitle title={t(lang, "helpCap")} />
      {BLOCKS.map(([title, body]) => (
        <p className="lead" key={title}>
          <b>{t(lang, title)}</b> {t(lang, body)}
        </p>
      ))}
      <p className="lead">{t(lang, "helpPrem")}</p>
    </section>
  );
}
