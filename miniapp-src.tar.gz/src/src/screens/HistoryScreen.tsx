/** История сигналов Cortex: сколько сбылось и что было в последних. */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { pct } from "../lib/format";
import { Blank } from "../components/Blank";
import { Row } from "../components/Row";
import { SectionTitle } from "../components/SectionTitle";
import { Tiles } from "../components/Tiles";

export function HistoryScreen() {
  const lang = useApp((s) => s.lang);
  const venue = useApp((s) => s.venue);
  const hist = useLive((s) => s.sonar.hist);

  // Пока результатов нет, показывать нули как статистику нечестно.
  if (!hist || !hist.of) {
    return <Blank title={t(lang, "history")} hint={t(lang, "formulaUntil")} />;
  }

  return (
    <section className="pad">
      <SectionTitle
        title={t(lang, "history")}
        extra={t(lang, venue === "perp" ? "histPerp" : "histSpot")}
      />
      <Tiles
        items={[
          { label: t(lang, "guessedDir"), value: `${hist.hit}%` },
          { label: t(lang, "signalCount"), value: hist.of },
          { label: t(lang, "plansTp"), value: hist.tp, cls: "up" },
          { label: t(lang, "plansSl"), value: hist.sl, cls: "dn" },
          { label: t(lang, "missed"), value: hist.missed },
          { label: t(lang, "broken"), value: hist.broken },
        ]}
      />
      <p className="lead">{t(lang, "histLead", { pct: pct(hist.avg) })}</p>

      <SectionTitle title={t(lang, "last")} />
      {hist.items.map((item, i) => (
        <Row
          key={i}
          cls={item.win ? "up" : "dn"}
          ic={item.sym}
          title={item.sym}
          tag={t(lang, item.long ? "buy" : "sell")}
          value={pct(item.ret)}
          sub={t(lang, item.win ? "guessedOk" : "missedOk")}
          extra={t(lang, "ago", { t: item.t })}
        />
      ))}
    </section>
  );
}
