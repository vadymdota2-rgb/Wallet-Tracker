/** Открывает верхний экран стека. Стек ведёт `useApp.open` / `back`. */

import { useApp } from "../store";
import type { ScreenName } from "./registry";
import { CoinScreen } from "./CoinScreen";
import { SignalScreen } from "./SignalScreen";
import { WalletScreen } from "./WalletScreen";
import { PositionScreen } from "./PositionScreen";
import { TraderScreen } from "./TraderScreen";
import { AddWalletScreen } from "./AddWalletScreen";
import { AnalyzeScreen } from "./AnalyzeScreen";
import { ReportScreen } from "./ReportScreen";
import { HistoryScreen } from "./HistoryScreen";
import { ModelScreen } from "./ModelScreen";
import { ThresholdScreen } from "./ThresholdScreen";
import { PremiumScreen } from "./PremiumScreen";
import { LangScreen } from "./LangScreen";
import { HelpScreen } from "./HelpScreen";
import { PositionsScreen } from "./PositionsScreen";

export function ScreenStack() {
  const stack = useApp((s) => s.stack);
  const top = stack[stack.length - 1];
  if (!top) return null;

  const arg = top.arg ?? "";
  switch (top.name as ScreenName) {
    case "coin":      return <CoinScreen sym={arg} />;
    case "signal":    return <SignalScreen sym={arg} />;
    case "wallet":    return <WalletScreen id={arg} />;
    case "pos":       return <PositionScreen refKey={arg} />;
    case "trader":    return <TraderScreen refKey={arg} />;
    case "add":       return <AddWalletScreen />;
    case "analyze":   return <AnalyzeScreen />;
    case "report":    return <ReportScreen addr={arg} />;
    case "history":   return <HistoryScreen />;
    case "model":     return <ModelScreen />;
    case "threshold": return <ThresholdScreen />;
    case "premium":   return <PremiumScreen />;
    case "lang":      return <LangScreen />;
    case "help":      return <HelpScreen />;
    case "positions": return <PositionsScreen />;
    default:          return null;
  }
}
