/**
 * Перевод строки. Подстановки вида `{n}` заменяются значениями из params.
 * Недостающий ключ в языке берётся из английского — этим пользуется только
 * арабский, остальные словари полные и проверяются компилятором.
 */

import { dictFor } from "./index";
import type { DictKey, LangCode } from "./types";

export function t(
  lang: LangCode,
  key: DictKey,
  params?: Record<string, string | number>,
): string {
  const raw = dictFor(lang)[key] ?? key;
  if (!params) return raw;
  return raw.replace(/\{(\w+)\}/g, (whole, name: string) =>
    name in params ? String(params[name]) : whole,
  );
}
