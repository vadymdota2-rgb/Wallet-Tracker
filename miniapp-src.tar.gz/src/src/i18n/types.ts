// Английский словарь задаёт набор ключей: остальные обязаны ему соответствовать.
// Пропустишь ключ в переводе — компилятор скажет сразу, а не пользователь потом.
import { en } from "./en";

export type DictKey = keyof typeof en;
export type Dict = Record<DictKey, string>;

export type LangCode =
  | "en" | "ru" | "uk" | "vi" | "ko" | "zh" | "ja" | "es"
  | "pt" | "fr" | "de" | "tr" | "hi" | "id" | "ar" | "pl";
