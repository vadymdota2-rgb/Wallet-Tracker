// Реестр языков. Порядок совпадает с тем, что был в бандле.
import { en } from "./en";
import { ru } from "./ru";
import { uk } from "./uk";
import { vi } from "./vi";
import { ko } from "./ko";
import { zh } from "./zh";
import { ja } from "./ja";
import { es } from "./es";
import { pt } from "./pt";
import { fr } from "./fr";
import { de } from "./de";
import { tr } from "./tr";
import { hi } from "./hi";
import { id } from "./id";
import { ar } from "./ar";
import { pl } from "./pl";
import type { Dict, LangCode } from "./types";
export type { Dict, LangCode };

export const LANGS: { id: LangCode; name: string }[] = [
  { id: "en", name: "English" },
  { id: "ru", name: "Русский" },
  { id: "uk", name: "Українська" },
  { id: "vi", name: "Tiếng Việt" },
  { id: "ko", name: "한국어" },
  { id: "zh", name: "中文" },
  { id: "ja", name: "日本語" },
  { id: "es", name: "Español" },
  { id: "pt", name: "Português" },
  { id: "fr", name: "Français" },
  { id: "de", name: "Deutsch" },
  { id: "tr", name: "Türkçe" },
  { id: "hi", name: "हिन्दी" },
  { id: "id", name: "Bahasa Indonesia" },
  { id: "ar", name: "العربية" },
  { id: "pl", name: "Polski" },
];

const TABLES: Record<LangCode, Partial<Dict>> = {
  en,
  ru,
  uk,
  vi,
  ko,
  zh,
  ja,
  es,
  pt,
  fr,
  de,
  tr,
  hi,
  id,
  ar,
  pl,
};

/** Арабский переведён не полностью — недостающее берётся из английского. */
export function dictFor(code: LangCode): Dict {
  return { ...en, ...(TABLES[code] ?? {}) } as Dict;
}
