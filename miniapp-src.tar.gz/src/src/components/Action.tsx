/** Кнопка-действие во всю ширину. Со стрелкой или пометкой справа. */

import type { ReactNode } from "react";

export interface ActionProps {
  children: ReactNode;
  /** Правый край: обычно стрелка или текущее значение. */
  extra?: ReactNode;
  primary?: boolean;
  danger?: boolean;
  disabled?: boolean;
  onClick?: () => void;
}

export function Action({ children, extra, primary, danger, disabled, onClick }: ActionProps) {
  return (
    <button
      type="button"
      className={`act${primary ? " primary" : ""}${danger ? " danger" : ""}`}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
      {extra ? <span>{extra}</span> : null}
    </button>
  );
}
