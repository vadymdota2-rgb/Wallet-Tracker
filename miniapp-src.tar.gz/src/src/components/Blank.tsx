/** Пустой экран: крупный заголовок и подсказка, что делать. */

import type { ReactNode } from "react";

export function Blank({ title, hint }: { title: ReactNode; hint?: ReactNode }) {
  return (
    <div className="blank">
      <b>{title}</b>
      {hint}
    </div>
  );
}
