/**
 * Значки интерфейса. Рисуются линиями, наследуют цвет текста, поэтому
 * отдельных вариантов под тему не нужно.
 */

import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function Icon({ size = 22, children, ...rest }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const BackIcon = (p: IconProps) => (
  <Icon {...p}>
    <path d="M15 5 8 12l7 7" />
  </Icon>
);

export const BurgerIcon = (p: IconProps) => (
  <Icon {...p}>
    <path d="M4 7h16M4 12h16M4 17h16" />
  </Icon>
);

export const SyncIcon = (p: IconProps) => (
  <Icon {...p}>
    <path d="M20 11a8 8 0 0 0-14-4.5L4 9" />
    <path d="M4 13a8 8 0 0 0 14 4.5L20 15" />
    <path d="M4 5v4h4M20 19v-4h-4" />
  </Icon>
);

export const HomeIcon = (p: IconProps) => (
  <Icon {...p}>
    <rect x="3.5" y="3.5" width="7.5" height="7.5" rx="1.4" />
    <rect x="13" y="3.5" width="7.5" height="5" rx="1.4" />
    <rect x="3.5" y="13" width="7.5" height="7.5" rx="1.4" />
    <rect x="13" y="10.5" width="7.5" height="10" rx="1.4" />
  </Icon>
);

export const MarketIcon = (p: IconProps) => (
  <Icon {...p}>
    <path d="M3 17l5-6 4 4 5-8" />
    <path d="M14 7h4v4" />
  </Icon>
);

export const PeopleIcon = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="9" cy="8" r="3.2" />
    <path d="M3.5 19c.6-3.2 2.9-5 5.5-5s4.9 1.8 5.5 5" />
    <path d="M16 8.5a2.8 2.8 0 1 0 0-.2M17 14.4c2 .6 3.4 2.3 3.8 4.6" />
  </Icon>
);

export const SonarIcon = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="2" />
    <path d="M12 12 19 5" />
    <path d="M5.6 18.4a9 9 0 0 1 0-12.8" />
    <path d="M8.5 15.5a5 5 0 0 1 0-7" />
  </Icon>
);

export const PremiumIcon = (p: IconProps) => (
  <Icon {...p}>
    <path d="m12 3 2.6 5.6 6.1.8-4.5 4.2 1.2 6-5.4-3-5.4 3 1.2-6L3.3 9.4l6.1-.8z" />
  </Icon>
);

export const HelpIcon = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M9.6 9.4a2.5 2.5 0 1 1 3.3 2.4c-.6.2-.9.7-.9 1.4" />
    <path d="M12 17h.01" />
  </Icon>
);

export const LangIcon = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M3.5 9.5h17M3.5 14.5h17" />
    <path d="M12 3c2.4 2.6 3.6 5.6 3.6 9s-1.2 6.4-3.6 9c-2.4-2.6-3.6-5.6-3.6-9S9.6 5.6 12 3z" />
  </Icon>
);

export const AddIcon = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 5v14M5 12h14" />
  </Icon>
);
