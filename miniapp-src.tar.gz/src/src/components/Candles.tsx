/** Отрисовка свечей: сетка, тела с тенями, линия входа и текущей цены. */

import { price } from "../lib/format";

export interface Candle {
  o: number;
  h: number;
  l: number;
  c: number;
}

const WIDTH = 320;
const HEIGHT = 190;
/** Полоса справа под подписи цен. */
const GUTTER = 46;

export function Candles({
  data,
  entry,
  entryLabel,
}: {
  data: Candle[];
  entry?: number;
  entryLabel?: string;
}) {
  if (!data.length) return null;

  const withEntry = entry && entry > 0 ? [entry] : [];
  const top = Math.max(...data.map((c) => c.h), ...withEntry);
  const bottom = Math.min(...data.map((c) => c.l), ...withEntry);
  const span = top - bottom || 1;

  const y = (value: number) => 10 + (1 - (value - bottom) / span) * (HEIGHT - 24);
  const step = (WIDTH - GUTTER) / data.length;

  const last = data[data.length - 1];
  const lastY = last ? y(last.c) : 0;

  return (
    <svg
      className="chart"
      viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      {[0, 1, 2, 3].map((i) => {
        const value = bottom + (span * i) / 3;
        const gy = y(value);
        return (
          <g key={i}>
            <line className="g" x1={0} y1={gy} x2={WIDTH - GUTTER} y2={gy} />
            <text className="l" x={WIDTH - GUTTER + 6} y={gy + 3}>
              {price(value)}
            </text>
          </g>
        );
      })}

      {data.map((candle, i) => {
        const cx = i * step + step / 2;
        const color = candle.c >= candle.o ? "var(--color-up)" : "var(--color-dn)";
        const openY = y(candle.o);
        const closeY = y(candle.c);
        return (
          <g key={i}>
            <line x1={cx} y1={y(candle.h)} x2={cx} y2={y(candle.l)} stroke={color} strokeWidth={1} />
            <rect
              x={cx - step * 0.34}
              y={Math.min(openY, closeY)}
              width={step * 0.68}
              // Иначе доджи с равными открытием и закрытием исчезает.
              height={Math.max(1, Math.abs(closeY - openY))}
              fill={color}
            />
          </g>
        );
      })}

      {entry && entry > 0 ? (
        <>
          <line className="e" x1={0} y1={y(entry)} x2={WIDTH - GUTTER} y2={y(entry)} />
          {entryLabel ? (
            <text className="et" x={3} y={y(entry) - 5}>
              {entryLabel}
            </text>
          ) : null}
        </>
      ) : null}

      {last ? (
        <>
          <line className="nw" x1={0} y1={lastY} x2={WIDTH - GUTTER} y2={lastY} />
          <rect x={WIDTH - GUTTER + 2} y={lastY - 8} width={42} height={16} fill="var(--color-glow)" rx={2} />
          <text className="now" x={WIDTH - GUTTER + 6} y={lastY + 3}>
            {price(last.c)}
          </text>
        </>
      ) : null}
    </svg>
  );
}
