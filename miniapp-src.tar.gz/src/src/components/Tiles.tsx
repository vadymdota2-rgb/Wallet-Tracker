/** Сетка плиток «подпись — значение». */

import type { ReactNode } from "react";

export interface Tile {
  label: ReactNode;
  value: ReactNode;
  /** `up` или `dn` для окраски. */
  cls?: string;
}

export function Tiles({ items }: { items: Tile[] }) {
  return (
    <dl className="tiles">
      {items.map((tile, i) => (
        <div key={i}>
          <dt>{tile.label}</dt>
          <dd className={tile.cls}>{tile.value}</dd>
        </div>
      ))}
    </dl>
  );
}
