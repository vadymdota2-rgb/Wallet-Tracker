/** Поле поиска с кнопкой очистки. */

export function SearchBox({
  value,
  onChange,
  placeholder,
  clearLabel,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  clearLabel: string;
}) {
  return (
    <div className="search">
      <input
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        autoCapitalize="off"
        autoComplete="off"
        spellCheck={false}
      />
      {value ? (
        <button type="button" aria-label={clearLabel} onClick={() => onChange("")}>
          {"\u00d7"}
        </button>
      ) : null}
    </div>
  );
}
