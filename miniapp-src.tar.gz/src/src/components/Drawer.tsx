/** Выдвижное меню: разделы приложения и переход в чат бота. */

import { useApp } from "../store";
import { useLive } from "../store/live";
import { t } from "../i18n/t";
import { plural, thresholdLabel } from "../lib/format";
import {
  AddIcon, HelpIcon, HomeIcon, LangIcon, MarketIcon,
  PeopleIcon, PremiumIcon, SonarIcon,
} from "./icons";
import type { ReactNode } from "react";
import type { DictKey } from "../i18n/types";

/** Номер сборки подставляется при сборке, а не зашит числом 27, как было. */
declare const __BUILD__: string;

type Entry = {
  id: string;
  title: DictKey;
  hint: DictKey;
  icon: ReactNode;
  /** Значение справа: например текущий порог. */
  value?: string;
  /** Вкладка или экран поверх неё. */
  tab?: boolean;
};

export function Drawer() {
  const lang = useApp((s) => s.lang);
  const open = useApp((s) => s.open);
  const goTab = useApp((s) => s.goTab);
  const setMenu = useApp((s) => s.setMenu);
  const menuOpen = useApp((s) => s.menuOpen);
  const wallets = useApp((s) => s.wallets);
  const tab = useApp((s) => s.tab);
  const stack = useApp((s) => s.stack);
  const threshold = useApp((s) => s.threshold);
  const { alertsToday, live } = useLive();

  const entries: (Entry | null)[] = [
    { id: "home", title: "home", hint: "homeHint", icon: <HomeIcon />, tab: true },
    { id: "market", title: "market", hint: "marketHint", icon: <MarketIcon />, tab: true },
    { id: "people", title: "people", hint: "peopleHint", icon: <PeopleIcon />, tab: true,
      value: String(wallets.length) },
    { id: "sonar", title: "sonar", hint: "sonarHint", icon: <SonarIcon />, tab: true },
    null,
    { id: "add", title: "addWallet", hint: "walletsHint", icon: <AddIcon /> },
    { id: "threshold", title: "alertThreshold", hint: "alertsCap", icon: <MarketIcon />,
      value: thresholdLabel(threshold) },
    null,
    { id: "premium", title: "premium", hint: "premiumHint", icon: <PremiumIcon /> },
    { id: "lang", title: "langCap", hint: "langHint", icon: <LangIcon /> },
    { id: "help", title: "help", hint: "helpHint", icon: <HelpIcon /> },
  ];

  const isCurrent = (id: string) => !stack.length && tab === id;

  const activate = (entry: Entry) => {
    setMenu(false);
    if (entry.tab) goTab(entry.id as never);
    else open(entry.id);
  };

  return (
    <>
      <div className={`scrim${menuOpen ? " show" : ""}`} onClick={() => setMenu(false)} />
      <aside className={`drawer${menuOpen ? " open" : ""}`} aria-label={t(lang, "menuAria")}>
        <div className="dhead">
          <b>Wallet Tracker</b>
          <span>
            {t(lang, "drawerSub", {
              w: plural(
                wallets.length,
                t(lang, "walletOne"),
                t(lang, "walletFew"),
                t(lang, "walletMany"),
              ),
              a: alertsToday,
              b: live ? `${__BUILD__} \u00b7 LIVE` : __BUILD__,
            })}
          </span>
        </div>
        <nav>
          {entries.map((entry, i) =>
            entry ? (
              <button
                key={entry.id}
                type="button"
                aria-current={isCurrent(entry.id) ? "page" : undefined}
                onClick={() => activate(entry)}
              >
                <span className="icn">{entry.icon}</span>
                <b>{t(lang, entry.title)}</b>
                {entry.value ? <em>{entry.value}</em> : null}
                <small>{t(lang, entry.hint)}</small>
              </button>
            ) : (
              <hr key={`hr${i}`} />
            ),
          )}
        </nav>
      </aside>
    </>
  );
}
