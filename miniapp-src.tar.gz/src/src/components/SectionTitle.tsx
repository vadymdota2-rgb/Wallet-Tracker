/** Заголовок раздела с необязательным примечанием справа. */

import type { ReactNode } from "react";

export function SectionTitle({ title, extra }: { title: ReactNode; extra?: ReactNode }) {
  return (
    <div className="h2">
      <b>{title}</b>
      {extra ? <em>{extra}</em> : null}
    </div>
  );
}
