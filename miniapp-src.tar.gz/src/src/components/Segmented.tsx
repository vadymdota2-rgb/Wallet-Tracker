/** Горизонтальный переключатель: вкладки раздела или окно времени. */

export interface SegmentedProps<T extends string | number> {
  items: [T, string][];
  value: T;
  onChange: (value: T) => void;
  /** Прокручиваемая полоса вкладок вместо равных долей. */
  scroll?: boolean;
}

export function Segmented<T extends string | number>({
  items,
  value,
  onChange,
  scroll,
}: SegmentedProps<T>) {
  return (
    <div className={scroll ? "segs" : "seg"} role="tablist">
      {items.map(([id, label]) => (
        <button
          key={String(id)}
          type="button"
          role="tab"
          aria-selected={id === value}
          className={id === value ? "on" : undefined}
          onClick={() => onChange(id)}
        >
          {label}
        </button>
      ))}
    </div>
  );
}
