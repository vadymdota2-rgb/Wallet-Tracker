/** Полоса оценки 0–100 с подписью, что эта оценка означает. */

export function ScoreBar({ score, label }: { score: number; label: string }) {
  const clamped = Math.max(0, Math.min(100, score));
  const tone = clamped >= 75 ? "up" : clamped >= 50 ? "" : "dn";
  return (
    <div className="score">
      <div className={`sv ${tone}`}>
        <b>{clamped}</b>
        <span>{label}</span>
      </div>
      <div className="sbar">
        <i style={{ width: `${clamped}%` }} className={tone} />
      </div>
    </div>
  );
}

/** Словесная оценка истории по тому же порогу, что и окраска. */
export function historyKey(score: number): "strongHist" | "mixedHist" | "weakHist" {
  return score >= 75 ? "strongHist" : score >= 50 ? "mixedHist" : "weakHist";
}
