/**
 * «Пульс» в шапке экрана: итог за сутки, полоса соотношения покупок и
 * продаж, подписи по краям.
 */

import { signed } from "../lib/format";

export interface PulseProps {
  /** Итог со знаком. */
  net: number;
  caption: string;
  buy: number;
  sell: number;
  boughtLabel: string;
  soldLabel: string;
}

export function Pulse({ net, caption, buy, sell, boughtLabel, soldLabel }: PulseProps) {
  const total = buy + sell;
  // Без сделок обе половины равны: полоса не должна схлопываться в NaN.
  const buyPct = total > 0 ? Math.round((buy / total) * 100) : 50;
  return (
    <div className="pulse">
      <div className={`n ${net >= 0 ? "up" : "dn"}`}>{signed(net)}</div>
      <div className="c">{caption}</div>
      <div className="flowbar">
        <i className="b" style={{ width: `${buyPct}%` }} />
        <i className="s" style={{ width: `${100 - buyPct}%` }} />
      </div>
      <div className="flowlab">
        <span>{boughtLabel}</span>
        <span>{soldLabel}</span>
      </div>
    </div>
  );
}
