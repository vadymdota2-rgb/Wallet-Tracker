/** Строка списка: иконка монеты, заголовок с пометкой, значение и две подписи. */

import type { ReactNode } from "react";
import { CoinIcon } from "./CoinIcon";

export interface RowProps {
  /** Дополнительный класс — обычно `up` или `dn` для окраски значения. */
  cls?: string;
  /** Тикер: если задан, слева рисуется логотип монеты. */
  ic?: string;
  title: ReactNode;
  /** Мелкая пометка рядом с заголовком, например «основной». */
  tag?: ReactNode;
  value?: ReactNode;
  /** Подпись под заголовком. */
  sub?: ReactNode;
  /** Подпись справа снизу. */
  extra?: ReactNode;
  onClick?: () => void;
}

export function Row({ cls, ic, title, tag, value, sub, extra, onClick }: RowProps) {
  const className = `row ${cls ?? ""}${ic ? " ico" : ""}`;
  const content = (
    <>
      {ic ? <CoinIcon sym={ic} /> : null}
      <span className="t">
        {title}
        {tag ? <i>{tag}</i> : null}
      </span>
      <span className="v">{value}</span>
      <span className="s">{sub ?? ""}</span>
      <span className="x">{extra ?? ""}</span>
    </>
  );
  // Без обработчика строка не должна быть кнопкой: иначе она попадает
  // в обход с клавиатуры и читается как интерактивная.
  return onClick ? (
    <button type="button" className={className} onClick={onClick}>
      {content}
    </button>
  ) : (
    <div className={className}>{content}</div>
  );
}
