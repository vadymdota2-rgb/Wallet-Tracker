/** Заглушка раздела, доступного только по подписке. */

import { Action } from "./Action";

export function Locked({
  title,
  hint,
  cta,
  onClick,
}: {
  title: string;
  hint: string;
  cta: string;
  onClick: () => void;
}) {
  return (
    <section className="pad">
      <div className="blank">
        <b>{title}</b>
        {hint}
      </div>
      <Action primary onClick={onClick}>
        {cta}
      </Action>
    </section>
  );
}
