/**
 * График с переключателем интервала, отметкой входа и ссылкой на
 * TradingView.
 *
 * Когда котировки не пришли, показывается прямая надпись об этом.
 * Раньше в этом случае рисовалась выдуманная прямая между ценой входа и
 * текущей — по виду обычный график, по сути ничего.
 */

import { useEffect, useState } from "react";
import { useApp } from "../store";
import { t } from "../i18n/t";
import { pct, price, signed } from "../lib/format";
import { fetchCandles, tradingViewUrl, type Timeframe } from "../lib/klines";
import { Action } from "./Action";
import { Candles, type Candle } from "./Candles";
import { Segmented } from "./Segmented";

const TFS: Timeframe[] = ["15m", "1h", "4h", "1d", "1w"];

/** Окно экрана переводится в интервал свечей. */
const FROM_WINDOW: Record<string, Timeframe> = {
  "1h": "15m",
  "24h": "1h",
  "7d": "4h",
  "30d": "1d",
};

export function Chart({
  sym,
  window,
  entry,
  pnl,
  pct: pctProp,
  note,
}: {
  sym: string;
  window?: string;
  entry?: number;
  pnl?: number;
  pct?: number;
  /** Подпись под графиком: получает число загруженных свечей. */
  note?: (candles: number) => string;
}) {
  const lang = useApp((s) => s.lang);
  const [tf, setTf] = useState<Timeframe>(FROM_WINDOW[window ?? ""] ?? "15m");
  const [data, setData] = useState<Candle[] | null>(null);

  useEffect(() => {
    const ctrl = new AbortController();
    setData(null);
    void fetchCandles(sym, tf, ctrl.signal).then((rows) => {
      if (!ctrl.signal.aborted) setData(rows);
    });
    return () => ctrl.abort();
  }, [sym, tf]);

  const last = data?.length ? data[data.length - 1]?.c : undefined;
  // Доходность считаем сами только если её не передали и есть обе цены.
  const roi =
    pctProp ?? (entry && entry > 0 && last ? ((last - entry) / entry) * 100 : undefined);

  // Имя `window` занято свойством компонента, поэтому обращаемся явно.
  const openChart = () => {
    const href = tradingViewUrl(sym);
    const wa = globalThis.window.Telegram?.WebApp;
    try {
      if (wa?.openLink) wa.openLink(href);
      else globalThis.window.open(href, "_blank");
    } catch {
      globalThis.window.open(href, "_blank");
    }
  };

  return (
    <div className="chartbox">
      <Segmented<Timeframe>
        value={tf}
        onChange={setTf}
        items={TFS.map((id) => [id, id.toUpperCase()])}
      />

      {data === null ? (
        <div className="chart-msg">{t(lang, "learning")}</div>
      ) : data.length ? (
        <Candles
          data={data}
          entry={entry}
          entryLabel={entry && entry > 0 ? t(lang, "entry", { v: price(entry) }) : undefined}
        />
      ) : (
        <div className="chart-msg">{t(lang, "noCoinHint")}</div>
      )}

      {note && data?.length ? <p className="lead">{note(data.length)}</p> : null}

      {entry && entry > 0 ? (
        <div className="chart-mark">
          <span className="entry">{t(lang, "entry", { v: price(entry) })}</span>
          <span className={roi !== undefined && roi >= 0 ? "up" : "dn"}>
            {roi !== undefined ? pct(roi) : ""}
            {pnl !== undefined ? ` \u00b7 ${signed(pnl)}` : ""}
          </span>
        </div>
      ) : null}

      <Action primary onClick={openChart}>
        TradingView
      </Action>
    </div>
  );
}
