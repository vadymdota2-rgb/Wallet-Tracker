/**
 * Логотип монеты.
 *
 * Источник определяется площадкой, а не тикером: у спотовых токенов BSC
 * есть адрес контракта, у перпов Hyperliquid его нет. Раньше первым делом
 * шёл поиск в TradingView по тикеру — а тикеры не уникальны, и под `PUMP`
 * с `HYPE` там лежали чужие проекты. Картинка грузилась успешно, ошибки не
 * было, и до правильной очередь не доходила.
 *
 * Список кандидатов приходит с сервера полем `icon`: он умеет считать
 * контрольную сумму адреса (EIP-55) и знает, какие файлы лежат локально.
 * Здесь остаётся перебор по ошибке загрузки.
 */

import { useState } from "react";
import { useLive } from "../store/live";

/** Имена монет Hyperliquid, отличные от тикера. */
const HL_ALIAS: Record<string, string> = {
  PEPE: "kPEPE",
  FLOKI: "kFLOKI",
  SHIB: "kSHIB",
  BONK: "kBONK",
  NVDA: "xyz:NVDA",
  INTC: "xyz:INTC",
  GOOGL: "xyz:GOOGL",
  GOOG: "xyz:GOOGL",
};

/** Выверенные вручную адреса для крупных монет — последнее звено цепочки. */
import { CG_FALLBACK } from "./coin-icon-fallback";

export function CoinIcon({ sym, size = 30 }: { sym: string; size?: number }) {
  const [step, setStep] = useState(0);
  const coins = useLive((s) => s.coins);

  const key = normalize(sym);
  const coin = coins?.[sym] ?? coins?.[key];
  const alias = HL_ALIAS[key] ?? key;

  const urls: string[] = [];
  const fromServer = coin?.icon;
  if (Array.isArray(fromServer)) urls.push(...fromServer.filter(Boolean));
  else if (typeof fromServer === "string" && fromServer.startsWith("/")) urls.push(fromServer);

  // Запасной путь на случай старого ответа API. Проверки «только если нет
  // адреса» здесь нет намеренно: у ZEC адрес есть — существует одноимённый
  // токен на BSC, — и такая проверка оставляла монету вовсе без иконки.
  if (key) {
    urls.push(`/hllogo/${alias}.svg`);
    if (alias !== key) urls.push(`/hllogo/${key}.svg`);
  }
  if (CG_FALLBACK[key]) urls.push(CG_FALLBACK[key]);

  const src = urls[step];
  const letter = key.slice(0, 1) || "?";

  return (
    <span className="ci" style={{ width: size, height: size }} aria-hidden="true">
      <b>{letter}</b>
      {src ? (
        <img
          src={src}
          alt=""
          loading="lazy"
          decoding="async"
          onError={() => setStep((n) => n + 1)}
        />
      ) : null}
    </span>
  );
}

/** Тикер в верхнем регистре без разделителей; `kPEPE` сводится к `PEPE`. */
function normalize(sym: string): string {
  const up = String(sym || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
  return up.startsWith("K") && ["PEPE", "FLOKI", "SHIB", "BONK"].includes(up.slice(1))
    ? up.slice(1)
    : up;
}
