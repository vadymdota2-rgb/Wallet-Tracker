/**
 * Фоновая анимация: перспективная сетка с редкими вспышками.
 *
 * Декоративная и полностью необязательная. Останавливается, когда вкладка
 * скрыта, и не запускается вовсе, если человек просил меньше движения —
 * прежняя версия крутила отрисовку постоянно, тратя батарею.
 */

import { useEffect, useRef } from "react";

/** Сколько плиток вдоль и поперёк. */
const ROWS = 14;
const COLS = 18;
const HORIZON = 0.34;

interface Spark {
  x: number;
  z: number;
  life: number;
}

export function Background() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    const still = matchMedia("(prefers-reduced-motion: reduce)").matches;
    let frame = 0;
    let width = 0;
    let height = 0;
    const sparks: Spark[] = [];

    const resize = () => {
      const dpr = Math.min(2, devicePixelRatio || 1);
      width = canvas.clientWidth;
      height = canvas.clientHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    /** Точка сетки в перспективе: z от 0 у горизонта до 1 у зрителя. */
    const project = (x: number, z: number) => {
      const scale = 0.12 + z * z * 0.88;
      return {
        X: width / 2 + (x - 0.5) * width * scale * 2.2,
        Y: height * HORIZON + (height * (1 - HORIZON)) * scale,
        s: scale,
      };
    };

    const grid = () => {
      ctx.lineWidth = 1;
      for (let i = 0; i <= ROWS; i++) {
        const z = i / ROWS;
        const a = project(0, z);
        const b = project(1, z);
        ctx.strokeStyle = `rgba(127,216,255,${(0.03 + a.s * 0.07).toFixed(3)})`;
        ctx.beginPath();
        ctx.moveTo(a.X, a.Y);
        ctx.lineTo(b.X, b.Y);
        ctx.stroke();
      }
      for (let j = 0; j <= COLS; j++) {
        const x = j / COLS;
        const near = project(x, 1);
        const far = project(x, 0);
        ctx.strokeStyle = "rgba(127,216,255,0.05)";
        ctx.beginPath();
        ctx.moveTo(far.X, far.Y);
        ctx.lineTo(near.X, near.Y);
        ctx.stroke();
      }
    };

    const flashes = () => {
      if (sparks.length < 3 && Math.random() < 0.006) {
        sparks.push({ x: Math.random(), z: 0, life: 1 });
      }
      for (let i = sparks.length - 1; i >= 0; i--) {
        const s = sparks[i];
        if (!s) continue;
        s.z += 0.004;
        s.life -= 0.004;
        if (s.life <= 0 || s.z > 1) {
          sparks.splice(i, 1);
          continue;
        }
        const tail = project(s.x, Math.max(0, s.z - 0.12));
        const head = project(s.x, s.z);
        const grad = ctx.createLinearGradient(tail.X, tail.Y, head.X, head.Y);
        grad.addColorStop(0, "rgba(127,216,255,0)");
        grad.addColorStop(1, `rgba(127,216,255,${(s.life * 0.45).toFixed(3)})`);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(tail.X, tail.Y);
        ctx.lineTo(head.X, head.Y);
        ctx.stroke();
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      grid();
      flashes();
      frame = requestAnimationFrame(draw);
    };

    const stop = () => {
      cancelAnimationFrame(frame);
      frame = 0;
    };
    const start = () => {
      if (!frame && !still) frame = requestAnimationFrame(draw);
    };

    resize();
    if (still) {
      ctx.clearRect(0, 0, width, height);
      grid();
    } else {
      start();
    }

    const onResize = () => {
      resize();
      if (still) grid();
    };
    const onVisibility = () => (document.hidden ? stop() : start());

    addEventListener("resize", onResize);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      stop();
      removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  return <canvas ref={ref} className="bg-canvas" aria-hidden="true" />;
}
