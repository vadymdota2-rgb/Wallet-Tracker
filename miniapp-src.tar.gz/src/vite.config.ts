import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "node:path";

/**
 * Сборка под статику в nginx, а не под Vercel: контейнер Cloud Run — это
 * nginx с папкой `html/`. Конфигурация из шаблона Grok собирала через
 * nitro с пресетом vercel и здесь не подходит.
 *
 * Имена файлов с содержательным хешем — обязательно. Прежняя сборка
 * складывала `routes.js` и `live.js` без хеша, а nginx отдавал `/assets/`
 * как неизменяемые на год: после выката браузер брал новый `app.js`
 * вместе с прошлогодним `routes.js` и падал с «Unexpected end of input».
 */
export default defineConfig({
  plugins: [react()],
  define: {
    // Номер сборки. В прежней версии он был зашит числом 27 прямо в меню.
    __BUILD__: JSON.stringify(process.env.BUILD_NUMBER ?? new Date().toISOString().slice(0, 10)),
  },
  resolve: {
    alias: { "@": resolve(__dirname, "src") },
  },
  build: {
    outDir: "html",
    emptyOutDir: false, // в html/ лежат ещё логотипы — их сборка не трогает
    assetsDir: "assets",
    target: "es2022",
    sourcemap: false,
    rollupOptions: {
      output: {
        entryFileNames: "assets/[name]-[hash].js",
        chunkFileNames: "assets/[name]-[hash].js",
        assetFileNames: "assets/[name]-[hash][extname]",
      },
    },
  },
});
