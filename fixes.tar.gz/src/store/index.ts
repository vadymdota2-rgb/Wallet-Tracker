/**
 * Состояние приложения. Всё в одном хранилище zustand — так было и в
 * бандле; дробить пока не стал, чтобы восстановление оставалось сверяемым
 * с оригиналом.
 *
 * В localStorage под ключом `wt-miniapp-v6` сохраняется только то, что
 * переживает перезапуск: язык, кошельки, порог и подписка. Остальное —
 * выбранные вкладки, окна, поисковые строки — живёт до закрытия.
 */

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { toast } from "sonner";
import { haptic } from "../lib/haptic";
import { shortAddr, usd, ADDR_RE } from "../lib/format";
import { t as translate } from "../i18n/t";
import type { LangCode } from "../i18n/types";
import type { Plan, Position, Venue, Wallet } from "../lib/types";
import * as api from "../lib/api";

/** Лимит кошельков по подписке. Те же числа, что в premium.cpp у бота. */
export const walletLimit = (plan: Plan): number => (plan === "premium" ? 50 : 1);

/** Кошелёк на паузе: на бесплатном плане алерты идут только с основного. */
export const isPaused = (plan: Plan, primary: boolean): boolean =>
  plan !== "premium" && !primary;

export const DEFAULT_THRESHOLD = 100;
export const MIN_THRESHOLD = 50;

export type Tab = "home" | "market" | "people" | "sonar";
export type MarketView =
  | "flow" | "heat" | "rot" | "feed" | "spot" | "perp" | "liq" | "fund";
export type PeopleView = "mine" | "top" | "check";
export type SonarView = "signals" | "history" | "model";

/** Экран, открытый поверх вкладки. Стек — как история переходов. */
export interface StackItem {
  name: string;
  arg?: string;
}

interface AppState {
  ready: boolean;
  launched: boolean;
  lang: LangCode;

  tab: Tab;
  stack: StackItem[];
  menuOpen: boolean;

  market: MarketView;
  win: number;
  venue: Venue;
  people: PeopleView;
  sonar: SonarView;
  sonarWin: number;
  sonarSide: "long" | "short";
  tf: string;
  rank: "pnl" | "roi" | "win" | "act";
  rankWin: number;
  rankVenue: Venue;
  rotWin: number;
  sortFlow: "net" | "vol" | "w";
  qFlow: string;
  qTop: string;
  qMine: string;

  syncedAt: number;
  wallets: Wallet[];
  threshold: number;
  plan: Plan;
  premUntil: number;
  /** id кошелька, который сейчас переименовывают. */
  renaming: string | null;

  setReady(): void;
  launch(opts?: { tab?: Tab; people?: PeopleView; market?: MarketView; stack?: string }): void;
  closeApp(): void;
  setLang(lang: LangCode): void;
  goTab(tab: Tab): void;
  open(name: string, arg?: string): void;
  back(): void;
  setMenu(open: boolean): void;
  setMarket(view: MarketView): void;
  setWin(hours: number): void;
  setRotWin(hours: number): void;
  setSortFlow(by: "net" | "vol" | "w"): void;
  setPeople(view: PeopleView): void;
  setSonar(view: SonarView): void;
  setVenue(venue: Venue): void;
  setSonarWin(hours: number): void;
  setSonarSide(side: "long" | "short"): void;
  setTf(tf: string): void;
  setRank(by: "pnl" | "roi" | "win" | "act"): void;
  setRankWin(days: number): void;
  setRankVenue(venue: Venue): void;
  setQuery(field: "qFlow" | "qTop" | "qMine", value: string): void;
  syncNow(): void;
  addWallet(addr: string, name: string): boolean;
  removeWallet(id: string): void;
  setPrimary(id: string): void;
  renameWallet(id: string, name: string): void;
  setRenaming(id: string | null): void;
  setThreshold(usdValue: number): boolean;
  buyPremium(): void;
}

/**
 * Сначала меняем состояние, потом отправляем запрос. Интерфейс отвечает
 * мгновенно, а если сервер откажет — следующий `pullLive` вернёт правду.
 */
export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      ready: false,
      launched: false,
      lang: "en",

      tab: "home",
      stack: [],
      menuOpen: false,

      market: "flow",
      win: 24,
      venue: "spot",
      people: "mine",
      sonar: "signals",
      sonarWin: 24,
      sonarSide: "long",
      tf: "24h",
      rank: "pnl",
      rankWin: 30,
      rankVenue: "spot",
      rotWin: 24,
      sortFlow: "net",
      qFlow: "",
      qTop: "",
      qMine: "",

      syncedAt: Date.now(),
      wallets: [],
      threshold: DEFAULT_THRESHOLD,
      plan: "free",
      premUntil: 0,
      renaming: null,

      setReady: () => set({ ready: true }),

      launch: (opts) => {
        set({
          launched: true,
          menuOpen: false,
          tab: opts?.tab ?? "home",
          people: opts?.people ?? get().people,
          market: opts?.market ?? get().market,
          stack: opts?.stack ? [{ name: opts.stack }] : [],
        });
        haptic();
      },

      closeApp: () => {
        set({ launched: false, menuOpen: false, stack: [] });
        haptic();
      },

      setLang: (lang) => {
        // Отметка о ручном выборе: иначе язык Telegram перезаписал бы его.
        try {
          localStorage.setItem("wt.langSet", "1");
        } catch {
          /* приватный режим — обойдёмся без отметки */
        }
        set({ lang });
        toast.success(translate(lang, "toastLang"));
        haptic();
      },

      goTab: (tab) => {
        set({ tab, stack: [], menuOpen: false });
        haptic();
      },

      open: (name, arg) => {
        set((s) => ({ stack: [...s.stack, { name, arg }] }));
        haptic();
      },

      back: () => {
        const s = get();
        if (s.menuOpen) {
          set({ menuOpen: false });
          return;
        }
        if (!s.stack.length) return;
        set({ stack: s.stack.slice(0, -1), renaming: null });
        haptic();
      },

      setMenu: (menuOpen) => set({ menuOpen }),
      setMarket: (market) => set({ market }),
      setWin: (win) => set({ win }),
      setRotWin: (rotWin) => set({ rotWin }),
      setSortFlow: (sortFlow) => set({ sortFlow }),
      setPeople: (people) => set({ people }),
      setSonar: (sonar) => set({ sonar }),
      // На споте короткой стороны нет: при переходе возвращаем длинную.
      setVenue: (venue) =>
        set((s) => ({ venue, sonarSide: venue === "spot" ? "long" : s.sonarSide })),
      setSonarWin: (sonarWin) => set({ sonarWin }),
      setSonarSide: (sonarSide) => set({ sonarSide }),
      setTf: (tf) => set({ tf }),
      setRank: (rank) => set({ rank }),
      setRankWin: (rankWin) => set({ rankWin }),
      setRankVenue: (rankVenue) => set({ rankVenue }),
      setQuery: (field, value) => set({ [field]: value } as Partial<AppState>),

      syncNow: () => {
        set({ syncedAt: Date.now() });
        void api.fetchBootstrap().then((data) => {
          if (data) toast.success(translate(get().lang, "toastSync"));
          else toast.error(translate(get().lang, "toastSyncFailed"));
        });
        haptic();
      },

      addWallet: (addr, name) => {
        const { wallets, plan, lang } = get();
        const limit = walletLimit(plan);
        const clean = addr.trim();

        if (!ADDR_RE.test(clean)) {
          toast.error(translate(lang, "addrErr"));
          return false;
        }
        if (wallets.some((w) => w.addr.toLowerCase() === clean.toLowerCase())) {
          toast.error(translate(lang, "toastDup"));
          return false;
        }
        if (wallets.length >= limit) {
          toast.error(translate(lang, "toastFull", { n: limit }));
          return false;
        }

        const label = name.trim() || shortAddr(clean);
        // Заглушка до первого ответа сервера: пользователь видит кошелёк сразу.
        const fresh: Wallet = {
          id: "w" + Date.now(),
          name: label,
          addr: clean,
          short: shortAddr(clean),
          primary: wallets.length === 0,
          score: 50,
          bal: 0,
          trades: 0,
          win: 0,
          pf: 0,
          net: 0,
          dd: 0,
          spot: "\u2014",
          perp: "\u2014",
          d1: 0,
          pos: [],
        };
        set({ wallets: [...wallets, fresh], stack: [], tab: "people", people: "mine" });
        toast.success(translate(lang, "toastAdded"));
        haptic();
        void api.addWallet(clean, label);
        return true;
      },

      removeWallet: (id) => {
        const { wallets, lang } = get();
        const gone = wallets.find((w) => w.id === id);
        set({
          wallets: wallets.filter((w) => w.id !== id),
          stack: [],
          tab: "people",
          people: "mine",
        });
        toast.success(translate(lang, "toastRemoved"));
        haptic();
        if (gone) void api.removeWallet(gone.addr);
      },

      setPrimary: (id) => {
        const { wallets, lang, stack } = get();
        const target = wallets.find((w) => w.id === id);
        set({
          wallets: wallets.map((w) => ({ ...w, primary: w.id === id })),
          stack: stack.slice(0, -1),
        });
        toast.success(translate(lang, "toastPrimary"));
        haptic();
        if (target) void api.makePrimary(target.addr);
      },

      renameWallet: (id, name) => {
        const label = name.trim();
        if (!label) return;
        const { wallets, lang } = get();
        const target = wallets.find((w) => w.id === id);
        set({
          wallets: wallets.map((w) => (w.id === id ? { ...w, name: label } : w)),
          renaming: null,
        });
        toast.success(translate(lang, "toastRenamed"));
        haptic();
        if (target) void api.renameWallet(target.addr, label);
      },

      setRenaming: (renaming) => set({ renaming }),

      setThreshold: (usdValue) => {
        const { lang, stack } = get();
        if (usdValue < MIN_THRESHOLD) {
          toast.error(translate(lang, "minThr"));
          return false;
        }
        set({ threshold: usdValue, stack: stack.slice(0, -1) });
        toast.success(translate(lang, "toastThr", { v: usd(usdValue) }));
        haptic();
        void api.setThreshold(usdValue);
        return true;
      },

      /**
       * Локальная отметка о подписке. Настоящая покупка идёт через бота, и
       * следующий ответ сервера всё равно перезапишет план — здесь только
       * чтобы интерфейс не ждал.
       */
      buyPremium: () => {
        set({ plan: "premium", premUntil: Date.now() + 30 * 24 * 3600 * 1000 });
        toast.success(translate(get().lang, "toastPremOn"));
        haptic();
      },
    }),
    {
      name: "wt-miniapp-v6",
      skipHydration: true,
      partialize: (s) => ({
        lang: s.lang,
        wallets: s.wallets,
        threshold: s.threshold,
        plan: s.plan,
        premUntil: s.premUntil,
      }),
    },
  ),
);

export type { Position, Wallet };
