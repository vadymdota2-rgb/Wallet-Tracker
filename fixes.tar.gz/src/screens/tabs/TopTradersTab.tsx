/**
 * Топ-100 трейдеров.
 *
 * Окна, по которым сервер не отдаёт данные, помечены и недоступны.
 * В прежней сборке они были кликабельны, но за ними ничего не стояло:
 * прибыль за 30 дней умножалась на 1.85, 2.7 или 3.9, а доходность —
 * на 0.72, 0.58 или 0.44. Показывать такое как результат трейдера нельзя:
 * по этим числам люди решают, за кем идти.
 */

import { useApp } from "../../store";
import { useLive } from "../../store/live";
import { t } from "../../i18n/t";
import { pct, shortAddr, signed, usd } from "../../lib/format";
import { Action } from "../../components/Action";
import { Locked } from "../../components/Locked";
import { SearchBox } from "../../components/SearchBox";
import { SectionTitle } from "../../components/SectionTitle";
import { Segmented } from "../../components/Segmented";
import type { Venue } from "../../lib/types";

const WINDOWS: [number, "days30" | "days90" | "days180" | "year"][] = [
  [30, "days30"],
  [90, "days90"],
  [180, "days180"],
  [365, "year"],
];

/** Бесплатно видно тридцать строк, по подписке — сто. */
const freeRows = (plan: string) => (plan === "premium" ? 100 : 30);

export function TopTradersTab() {
  const lang = useApp((s) => s.lang);
  const sort = useApp((s) => s.rank);
  const setSort = useApp((s) => s.setRank);
  const win = useApp((s) => s.rankWin);
  const setWin = useApp((s) => s.setRankWin);
  const venue = useApp((s) => s.rankVenue);
  const setVenue = useApp((s) => s.setRankVenue);
  const wallets = useApp((s) => s.wallets);
  const plan = useApp((s) => s.plan);
  const open = useApp((s) => s.open);
  const addWallet = useApp((s) => s.addWallet);
  const query = useApp((s) => s.qTop);
  const setQuery = useApp((s) => s.setQuery);
  const { rank, rankWindows } = useLive();

  const premium = plan === "premium";
  const venueLocked = !premium && venue === "perp";

  const rows = (rank[venue]?.[sort] ?? []).slice(0, freeRows(plan));
  const needle = query.trim().toLowerCase();
  const shown = rows
    .map((row, i) => ({ row, i }))
    .filter(({ row }) => !needle || row.a.toLowerCase().includes(needle));

  const owned = new Set(wallets.map((w) => w.addr.toLowerCase()));
  const windowHasData = rankWindows.includes(win);

  return (
    <>
      <Segmented<Venue>
        value={venue}
        onChange={setVenue}
        items={[
          ["spot", t(lang, "venueSpot")],
          ["perp", premium ? t(lang, "venuePerp") : `${t(lang, "venuePerp")} \u{1F512}`],
        ]}
      />
      <Segmented
        value={sort}
        onChange={setSort}
        items={[
          ["pnl", t(lang, "rankByPnl")],
          ["roi", t(lang, "rankByRoi")],
          ["win", t(lang, "rankByWin")],
          ["act", t(lang, "rankByAct")],
        ]}
      />
      <Segmented<number>
        value={win}
        onChange={setWin}
        items={WINDOWS.map(([days, key]) => [
          days,
          rankWindows.includes(days) ? t(lang, key) : `${t(lang, key)} \u2014`,
        ])}
      />

      {venueLocked ? (
        <Locked
          title={t(lang, "lockedTitle")}
          hint={t(lang, "lockedHint")}
          cta={t(lang, "lockedCta")}
          onClick={() => open("premium")}
        />
      ) : (
        <section className="pad">
          <SearchBox
            value={query}
            onChange={(v) => setQuery("qTop", v)}
            placeholder={t(lang, "findAddr")}
            clearLabel={t(lang, "clear")}
          />

          {!windowHasData ? (
            <p className="lead">{t(lang, "winNoData")}</p>
          ) : null}

          {needle && !shown.length ? (
            <p className="lead">{t(lang, "topNone", { q: query })}</p>
          ) : null}

          <SectionTitle
            title={t(lang, venue === "perp" ? "bestPerp" : "bestSpot")}
            extra={
              needle
                ? t(lang, "foundN", { n: shown.length })
                : t(lang, "of100", { n: rows.length })
            }
          />

          {windowHasData
            ? shown.map(({ row, i }) => {
                const already = owned.has(row.a.toLowerCase());
                return (
                  <div className="trow" key={row.a}>
                    <button
                      type="button"
                      className="tmain"
                      onClick={() => open("trader", `${venue}.${sort}.${i}`)}
                    >
                      <span className="pl">{i + 1}</span>
                      <span className="ad">{shortAddr(row.a)}</span>
                      <span className={`big ${row.pnl >= 0 ? "up" : "dn"}`}>
                        {signed(row.pnl)}
                      </span>
                      <span className="mt">
                        {t(lang, "rankMeta", {
                          roi: pct(row.roi, 0),
                          win: row.win,
                          tr: row.tr,
                        })}
                        {row.hold ? ` \u00b7 ${t(lang, "avgHold")} ${row.hold}` : ""}
                        {row.lev ? ` \u00b7 ${t(lang, "avgLev")} ${row.lev}\u00d7` : ""}
                      </span>
                      <span className="mt right">
                        {t(lang, "rankDd", { v: usd(row.dd) })}
                      </span>
                    </button>
                    <button
                      type="button"
                      className={`sub${already ? " on" : ""}`}
                      aria-label={t(lang, already ? "already" : "follow")}
                      disabled={already}
                      onClick={() =>
                        addWallet(row.a, t(lang, "traderN", { n: i + 1, by: t(lang, "byPnl") }))
                      }
                    >
                      {already ? "\u2713" : "+"}
                    </button>
                  </div>
                );
              })
            : null}

          <p className="lead">
            {t(lang, venue === "perp" ? "rankLeadPerp" : "rankLeadSpot")}
          </p>
          {premium ? null : (
            <Action extra={"\u2192"} onClick={() => open("premium")}>
              {t(lang, "unlockTop")}
            </Action>
          )}
        </section>
      )}
    </>
  );
}
